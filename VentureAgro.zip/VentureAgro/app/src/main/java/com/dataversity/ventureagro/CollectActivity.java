package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.dataversity.ventureagro.adapter.CollectionMasterAdapter;
import com.dataversity.ventureagro.model.CollectionMasterPojo;
import com.dataversity.ventureagro.utils.Tools;

import java.util.ArrayList;

public class CollectActivity extends Activity {
    RecyclerView collect_recyclerview;
    LinearLayoutManager category_layoutManager;
    CollectionMasterAdapter collectionMasterAdapter;
    CollectionMasterPojo collectionMasterPojo;
    private ArrayList<CollectionMasterPojo> collectionMasterPojoArrayList= new ArrayList<>();
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collect);
        context = this;

        Tools.setSystemBarColor(this, R.color.sub_primary);
        Tools.setSystemBarLight(this);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.check_out).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CheckOutActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.btn_continue).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CollectionMasterActivity.class);
                startActivity(intent);
                finish();
            }
        });

       // ShowCollectList();
    }

    /*private void ShowCollectList() {

        collect_recyclerview = findViewById(R.id.collect_recyclerview);

        category_layoutManager = new GridLayoutManager(context, 1);
        collectionMasterAdapter = new CollectionMasterAdapter(context);
        // Set the layout manager
        // and adapter for items
        // of the parent recyclerview

        CollectionMasterPojo pojoObject = new CollectionMasterPojo("Order ID: S256368", "$20", "02", "02/03/2021","09:30", "collected");
        CollectionMasterPojo pojoObject1 = new CollectionMasterPojo("Order ID: S256368", "$20", "02", "02/03/2021","09:30", "pending");

        //After setting the values, we add all the Objects to the array
        collectionMasterPojoArrayList.add(pojoObject);
        collectionMasterPojoArrayList.add(pojoObject1);

        collectionMasterAdapter.setListContent(collectionMasterPojoArrayList);
        collect_recyclerview.setAdapter(collectionMasterAdapter);
        collect_recyclerview.setLayoutManager(category_layoutManager);

    }*/
}