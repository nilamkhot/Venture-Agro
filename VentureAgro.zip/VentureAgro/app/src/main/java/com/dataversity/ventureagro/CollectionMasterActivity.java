package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.dataversity.ventureagro.adapter.CollectionMasterAdapter;
import com.dataversity.ventureagro.adapter.ShopCheckInAdapter;
import com.dataversity.ventureagro.model.CollectionMasterPojo;
import com.dataversity.ventureagro.model.ShopCheckInPojo;
import com.dataversity.ventureagro.utils.Tools;

import java.util.ArrayList;

public class CollectionMasterActivity extends Activity {
    RecyclerView collection_master_recyclerview;
    LinearLayoutManager category_layoutManager;
    CollectionMasterAdapter collectionMasterAdapter;
    CollectionMasterPojo collectionMasterPojo;
    private ArrayList<CollectionMasterPojo> collectionMasterPojoArrayList= new ArrayList<>();
    Context context;

    static final String[] Status = new String[] {"Collected", "Pending"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection_master);
        context = this;

        Tools.setSystemBarColor(this, R.color.sub_primary);
        Tools.setSystemBarLight(this);

        SetSpinnerStatus();

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.check_out).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CheckOutActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.skip).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, OrderSkippedActivity.class);
                intent.putExtra("activity", "Collection Skipped");
                startActivity(intent);
                finish();
            }
        });

        findViewById(R.id.btn_continue).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ShopListActivity.class);
                startActivity(intent);
                finish();
            }
        });

        ShowShopCheckInList();
    }

    private void ShowShopCheckInList() {

        collection_master_recyclerview = findViewById(R.id.collection_master_recyclerview);

        category_layoutManager = new GridLayoutManager(context, 1);
        collectionMasterAdapter = new CollectionMasterAdapter(context);
        // Set the layout manager
        // and adapter for items
        // of the parent recyclerview

        CollectionMasterPojo pojoObject = new CollectionMasterPojo("Order ID: S256368", "$20", "02", "02/03/2021","09:30", "collected");
        CollectionMasterPojo pojoObject1 = new CollectionMasterPojo("Order ID: S256368", "$20", "02", "02/03/2021","09:30", "pending");

        //After setting the values, we add all the Objects to the array
        collectionMasterPojoArrayList.add(pojoObject);
        collectionMasterPojoArrayList.add(pojoObject1);

        collectionMasterAdapter.setListContent(collectionMasterPojoArrayList);
        collection_master_recyclerview.setAdapter(collectionMasterAdapter);
        collection_master_recyclerview.setLayoutManager(category_layoutManager);

    }

    private void SetSpinnerStatus() {
        // Set months
        ArrayAdapter<String> adapterStatus = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, Status);
        adapterStatus.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Spinner spinStatus = (Spinner)findViewById(R.id.spinnerStatus);
        spinStatus.setAdapter(adapterStatus);
    }

}