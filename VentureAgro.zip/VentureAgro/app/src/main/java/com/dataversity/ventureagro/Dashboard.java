package com.dataversity.ventureagro;

import android.content.Context;
import android.os.Bundle;

import com.dataversity.ventureagro.utils.Tools;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class Dashboard extends AppCompatActivity {
    Context context;
    BottomNavigationView navView;
    String fragment ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        context = this;

        Bundle bundle = getIntent().getExtras();
        if(bundle != null) {
            fragment = bundle.getString("flag");
        }

        getSupportActionBar().hide();
        Tools.setSystemBarColor(this, R.color.sub_primary);
        Tools.setSystemBarLight(this);
        navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_attendence, R.id.navigation_collection, R.id.navigation_order, R.id.navigation_profile)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(fragment.matches("attendance")){
            navView.setSelectedItemId(R.id.navigation_attendence);

        }else if(fragment.matches("profile")){

            navView.setSelectedItemId(R.id.navigation_profile);

        }else {
            navView.setSelectedItemId(R.id.navigation_home);

        }


    }
}