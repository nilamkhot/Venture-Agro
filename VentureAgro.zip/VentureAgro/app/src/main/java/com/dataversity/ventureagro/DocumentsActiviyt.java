package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.dataversity.ventureagro.network.ApiService;
import com.dataversity.ventureagro.network.RetroInstance;
import com.dataversity.ventureagro.pojo.LoginRequestPojo;
import com.dataversity.ventureagro.pojo.PersonalInfoRequestPojo;
import com.dataversity.ventureagro.pojo.PersonalInfoResponsePojo;
import com.dataversity.ventureagro.pojo.SignUpRequestPojo;
import com.dataversity.ventureagro.pojo.SignUpResponsePojo;
import com.dataversity.ventureagro.utils.Shareutil;
import com.dataversity.ventureagro.utils.StaticDialog;
import com.dataversity.ventureagro.utils.Tools;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class DocumentsActiviyt extends Activity {
    Context context;
    TextInputEditText name_edit_text, email_edit_text,mobile_edit_text,date_edit_text,city_edit_text,address_edit_text;
    String name_txt, email_txt, mobile_txt,date_txt, city_txt, address_txt;
    String radioText = "";
    Calendar myCalendar;
    private RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_documents_activiyt);
        context = this;

       // getSupportActionBar().show();
        Tools.setSystemBarColor(this, R.color.sub_primary);
        Tools.setSystemBarLight(this);

        name_edit_text = findViewById(R.id.name_edit_text);
        email_edit_text = findViewById(R.id.email_edit_text);
        mobile_edit_text = findViewById(R.id.mobile_edit_text);
        date_edit_text = findViewById(R.id.date_edit_text);
        city_edit_text = findViewById(R.id.city_edit_text);
        address_edit_text = findViewById(R.id.address_edit_text);
        radioGroup = findViewById(R.id.radioGroup);

        if(!Shareutil.getPersonalInfo(context).getUsername().matches("")){
            name_edit_text.setText(Shareutil.getPersonalInfo(context).getUsername());
            email_edit_text.setText(Shareutil.getPersonalInfo(context).getEmail());
            mobile_edit_text.setText(Shareutil.getPersonalInfo(context).getPhone_No());
            date_edit_text.setText(Shareutil.getPersonalInfo(context).getDate());
            city_edit_text.setText(Shareutil.getPersonalInfo(context).getCity());
            address_edit_text.setText(Shareutil.getPersonalInfo(context).getAddress());
            radioText = Shareutil.getPersonalInfo(context).getGender();

            if(Shareutil.getPersonalInfo(context).getGender().equals("Male")) {
                radioGroup.check(R.id.Male);
            }else if(Shareutil.getPersonalInfo(context).getGender().equals("Female")){
                radioGroup.check(R.id.Female);
            }else {
                radioGroup.check(R.id.Other);
            }
        }

        //select date
        myCalendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };

        date_edit_text.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(DocumentsActiviyt.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        //select gender
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb=(RadioButton) findViewById(checkedId);

                radioText=rb.getText().toString();

            }
        });

        findViewById(R.id.next).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                name_txt = name_edit_text.getText().toString().trim();
                email_txt = email_edit_text.getText().toString().trim();
                mobile_txt = mobile_edit_text.getText().toString().trim();
                date_txt = date_edit_text.getText().toString().trim();
                city_txt = city_edit_text.getText().toString().trim();
                address_txt = address_edit_text.getText().toString().trim();

                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if(!email_txt.matches("") && !name_txt.matches("")
                        && !mobile_txt.matches("") && !date_txt.matches("")
                        && !city_txt.matches("") && !address_txt.matches("")
                        && !radioText.matches("")) {

                    if (email_txt.matches(emailPattern)) {

                        PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(Shareutil.getID(context),name_txt, email_txt,mobile_txt, date_txt,city_txt,address_txt,radioText);
                        Shareutil.savePersonalInfo(context,personalInfoRequestPojo);
                        Intent intent = new Intent(DocumentsActiviyt.this, KYCRegistrationActivity.class);
                        startActivity(intent);

                    } else {
                        Toast.makeText(getApplicationContext(), "Invalid email address", Toast.LENGTH_SHORT).show();
                    }

                }else {

                    Toast.makeText(getApplicationContext(), "Please Add All Fields.", Toast.LENGTH_SHORT).show();

                }

            }
        });
    }

    private void updateLabel() {
        String myFormat = "dd/MM/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        date_edit_text.setText(sdf.format(myCalendar.getTime()));
    }

    private void SetPersonalInfoMethod(PersonalInfoRequestPojo personalInfoRequestPojo) {
        StaticDialog.setDialog(context).show();
        RetroInstance retroInstance = new RetroInstance(context);
        ApiService apiService = retroInstance.getCachedRetrofit().create(ApiService.class);
        Call<PersonalInfoResponsePojo> call = apiService.SetPersonalnfo(personalInfoRequestPojo);
        call.enqueue(new Callback<PersonalInfoResponsePojo>() {
            @Override
            public void onResponse(Call<PersonalInfoResponsePojo> call, Response<PersonalInfoResponsePojo> response) {
                // Signed in successfully, show authenticated UI.
                if(response.isSuccessful()) {
                    Toast.makeText(context, response.body().getStatus(), Toast.LENGTH_LONG).show();
                    StaticDialog.setDialog(context).cancel();
                    Intent intent = new Intent(DocumentsActiviyt.this, KYCRegistrationActivity.class);
                    startActivity(intent);
                    finish();

                }else {
                    StaticDialog.setDialog(context).cancel();
                    Log.d("login_error", response.message());
                    Toast.makeText(context, R.string.try_again, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<PersonalInfoResponsePojo> call, Throwable t) {
                StaticDialog.setDialog(context).cancel();
                Log.d("login_error", t.toString());
                Toast.makeText(context, R.string.try_again, Toast.LENGTH_LONG).show();
            }
        });
    }
}