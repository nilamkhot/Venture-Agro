package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.dataversity.ventureagro.utils.Tools;
import com.google.android.material.textfield.TextInputEditText;

public class ForgotPassword extends Activity {
    Context context;
    TextInputEditText email_edit_text;
    Button reset_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        context = this;

        Tools.setSystemBarColor(this, R.color.primary);
        Tools.setSystemBarLight(this);

        email_edit_text = findViewById(R.id.email_edit_text);
        reset_password = findViewById(R.id.reset_password);

        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        reset_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!email_edit_text.getText().toString().matches("")){

                    if (email_edit_text.getText().toString().matches(emailPattern)) {


                    } else {
                        Toast.makeText(getApplicationContext(), "Invalid email address", Toast.LENGTH_SHORT).show();
                    }

                }else {
                    Toast.makeText(context, "Please Enter Email", Toast.LENGTH_LONG).show();
                }

            }
        });

    }
}