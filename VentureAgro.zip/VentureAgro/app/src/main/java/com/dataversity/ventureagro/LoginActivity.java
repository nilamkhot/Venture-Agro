package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.dataversity.ventureagro.network.ApiService;
import com.dataversity.ventureagro.network.RetroInstance;
import com.dataversity.ventureagro.pojo.LoginRequestPojo;
import com.dataversity.ventureagro.pojo.LoginResponsePojo;
import com.dataversity.ventureagro.pojo.SignUpRequestPojo;
import com.dataversity.ventureagro.pojo.SignUpResponsePojo;
import com.dataversity.ventureagro.utils.Shareutil;
import com.dataversity.ventureagro.utils.StaticDialog;
import com.dataversity.ventureagro.utils.Tools;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends Activity {
    Context context;
    TextInputEditText name_edit_text, password_edit_text;
    String name_txt, password_txt;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        context = this;

        //getSupportActionBar().hide();
        Tools.setSystemBarColor(this, R.color.primary);
        Tools.setSystemBarLight(this);

        name_edit_text = findViewById(R.id.name_edit_text);
        password_edit_text = findViewById(R.id.password_edit_text);

        findViewById(R.id.sign_up).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
                finish();
            }
        });

        findViewById(R.id.login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                password_txt = password_edit_text.getText().toString().trim();
                name_txt = name_edit_text.getText().toString().trim();

                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if(!password_txt.matches("") && !name_txt.matches("")) {

                   // if (name_txt.matches(emailPattern)) {

                        LoginRequestPojo loginRequestPojo = new LoginRequestPojo(name_txt,password_txt);
                        SetLoginMethod(loginRequestPojo);

                    /*} else {
                        Toast.makeText(getApplicationContext(), "Invalid email address", Toast.LENGTH_SHORT).show();
                    }*/

                }else {

                    Toast.makeText(getApplicationContext(), "Please Add All Fields.", Toast.LENGTH_SHORT).show();

                }

            }
        });

        findViewById(R.id.forgot_password).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, ForgotPassword.class);
                startActivity(intent);
                //finish();
            }
        });

    }

    private void SetLoginMethod(LoginRequestPojo loginRequestPojo) {
        mDialog = ProgressDialog.show(context,"Please wait...", "", true);
        RetroInstance retroInstance = new RetroInstance(context);
        ApiService apiService = retroInstance.getCachedRetrofit().create(ApiService.class);
        Call<LoginResponsePojo> call = apiService.SetLogin(loginRequestPojo);
        call.enqueue(new Callback<LoginResponsePojo>() {
            @Override
            public void onResponse(Call<LoginResponsePojo> call, Response<LoginResponsePojo> response) {
                // Signed in successfully, show authenticated UI.
                if(response.isSuccessful()) {

                    Log.d("id", response.body().getUser().get_id());

                    RetroInstance.access_token = response.body().getToken();
                    mDialog.dismiss();
                    Intent intent = new Intent(LoginActivity.this, DocumentsActiviyt.class);
                    startActivity(intent);
                    finish();

                }else {
                    mDialog.dismiss();
                    Log.d("login_error", response.message());
                    Toast.makeText(context, R.string.try_again, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponsePojo> call, Throwable t) {
                mDialog.dismiss();
                Log.d("login_error", t.toString());
                Toast.makeText(context, R.string.try_again, Toast.LENGTH_LONG).show();
            }
        });
    }

}