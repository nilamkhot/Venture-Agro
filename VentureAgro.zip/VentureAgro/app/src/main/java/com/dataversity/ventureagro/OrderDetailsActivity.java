package com.dataversity.ventureagro;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.dataversity.ventureagro.adapter.OrderDetailsAdapter;
import com.dataversity.ventureagro.model.OrderDetailsPojo;
import com.dataversity.ventureagro.utils.Tools;

import java.util.ArrayList;

public class OrderDetailsActivity extends Activity {
    RecyclerView order_details_recyclerview;
    LinearLayoutManager category_layoutManager;
    OrderDetailsAdapter orderDetailsAdapter;
    OrderDetailsPojo orderDetailsPojo;
    private ArrayList<OrderDetailsPojo> orderDetailsPojoArrayList= new ArrayList<>();
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);
        context = this;

        Tools.setSystemBarColor(this, R.color.sub_primary);
        Tools.setSystemBarLight(this);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.check_out).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CheckOutActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.confirm).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, OrderHistoryActivity.class);
                startActivity(intent);
            }
        });

        ShowOrderDetailsList();

    }

    private void ShowOrderDetailsList() {

        order_details_recyclerview = findViewById(R.id.order_details_recyclerview);

        category_layoutManager = new GridLayoutManager(context, 1);
        orderDetailsAdapter = new OrderDetailsAdapter();
        // Set the layout manager
        // and adapter for items
        // of the parent recyclerview

        orderDetailsAdapter.setListContent(orderDetailsPojoArrayList);
        order_details_recyclerview.setAdapter(orderDetailsAdapter);
        order_details_recyclerview.setLayoutManager(category_layoutManager);

    }
}