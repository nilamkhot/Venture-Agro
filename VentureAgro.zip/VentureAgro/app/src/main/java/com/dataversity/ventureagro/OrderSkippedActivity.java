package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.dataversity.ventureagro.utils.Tools;

public class OrderSkippedActivity extends Activity {
    Context context;
    String activity;
    TextView activity_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_skipped);
        context = this;

        Tools.setSystemBarColor(this, R.color.sub_primary);
        Tools.setSystemBarLight(this);

        Bundle bundle = getIntent().getExtras();
        activity = bundle.getString("activity");
        activity_name = findViewById(R.id.activity_name);
        activity_name.setText(activity);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.check_out).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CheckOutActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.comment).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ShopListActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}