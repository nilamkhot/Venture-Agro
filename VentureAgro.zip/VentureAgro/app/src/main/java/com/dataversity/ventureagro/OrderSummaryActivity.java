package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.dataversity.ventureagro.adapter.OrderSummaryListAdapter;
import com.dataversity.ventureagro.adapter.ShopListAdapter;
import com.dataversity.ventureagro.model.ShopListPojo;
import com.dataversity.ventureagro.utils.Tools;

import java.util.ArrayList;

public class OrderSummaryActivity extends Activity {
    RecyclerView shop_recyclerview;
    LinearLayoutManager category_layoutManager;
    OrderSummaryListAdapter orderSummaryListAdapter;
    ShopListPojo shopListPojo;
    private ArrayList<ShopListPojo> routePojoArrayList= new ArrayList<>();
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_summary);
        context = this;

        Tools.setSystemBarColor(this, R.color.sub_primary);
        Tools.setSystemBarLight(this);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OrderSummaryActivity.this, Dashboard.class);
                intent.putExtra("flag", "profile");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });

        ShowOrderSummary();

    }

    private void ShowOrderSummary() {

        shop_recyclerview = findViewById(R.id.shop_recyclerview);

        category_layoutManager = new GridLayoutManager(context, 1);
        orderSummaryListAdapter = new OrderSummaryListAdapter(context);
        // Set the layout manager
        // and adapter for items
        // of the parent recyclerview

        orderSummaryListAdapter.setListContent(routePojoArrayList);
        shop_recyclerview.setAdapter(orderSummaryListAdapter);
        shop_recyclerview.setLayoutManager(category_layoutManager);

    }

}