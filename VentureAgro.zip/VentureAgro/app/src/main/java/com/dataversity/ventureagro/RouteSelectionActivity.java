package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.dataversity.ventureagro.adapter.AttendanceListAdapter;
import com.dataversity.ventureagro.adapter.RouteListAdapter;
import com.dataversity.ventureagro.model.AttendencePojo;
import com.dataversity.ventureagro.model.RoutePojo;
import com.dataversity.ventureagro.utils.Tools;

import java.util.ArrayList;

public class RouteSelectionActivity extends Activity {
    RecyclerView route_recyclerview;
    LinearLayoutManager category_layoutManager;
    RouteListAdapter routeListAdapter;
    RoutePojo routePojo;
    private ArrayList<RoutePojo> routePojoArrayList= new ArrayList<>();
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route_selection);
        context = this;

        Tools.setSystemBarColor(this, R.color.sub_primary);
        Tools.setSystemBarLight(this);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.check_out).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RouteSelectionActivity.this, CheckOutActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.btn_continue).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RouteSelectionActivity.this, ShopListActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        ShowRouteList();

    }

    private void ShowRouteList() {

        route_recyclerview = findViewById(R.id.route_recyclerview);

        category_layoutManager = new GridLayoutManager(context, 1);
        routeListAdapter = new RouteListAdapter();
        // Set the layout manager
        // and adapter for items
        // of the parent recyclerview

        routeListAdapter.setListContent(routePojoArrayList);
        route_recyclerview.setAdapter(routeListAdapter);
        route_recyclerview.setLayoutManager(category_layoutManager);

    }
}