package com.dataversity.ventureagro;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.dataversity.ventureagro.adapter.ShopCheckInAdapter;
import com.dataversity.ventureagro.model.ShopCheckInPojo;
import com.dataversity.ventureagro.utils.Tools;

import java.util.ArrayList;

public class ShopCheckInActivity extends Activity {
    RecyclerView shop_checkin_recyclerview;
    LinearLayoutManager category_layoutManager;
    ShopCheckInAdapter shopCheckInAdapter;
    ShopCheckInPojo shopCheckInPojo;
    private ArrayList<ShopCheckInPojo> shopCheckInPojoArrayList= new ArrayList<>();
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_check_in);
        context = this;

        Tools.setSystemBarColor(this, R.color.sub_primary);
        Tools.setSystemBarLight(this);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.check_out).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShopCheckInActivity.this, CheckOutActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.skip).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShopCheckInActivity.this, OrderSkippedActivity.class);
                intent.putExtra("activity", "Order Skipped");
                startActivity(intent);
                finish();
            }
        });

        findViewById(R.id.btn_continue).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShopCheckInActivity.this, OrderDetailsActivity.class);
                startActivity(intent);
            }
        });

        ShowShopCheckInList();

    }

    private void ShowShopCheckInList() {

        shop_checkin_recyclerview = findViewById(R.id.shop_checkin_recyclerview);

        category_layoutManager = new GridLayoutManager(context, 1);
        shopCheckInAdapter = new ShopCheckInAdapter();
        // Set the layout manager
        // and adapter for items
        // of the parent recyclerview

        shopCheckInAdapter.setListContent(shopCheckInPojoArrayList);
        shop_checkin_recyclerview.setAdapter(shopCheckInAdapter);
        shop_checkin_recyclerview.setLayoutManager(category_layoutManager);

    }
}