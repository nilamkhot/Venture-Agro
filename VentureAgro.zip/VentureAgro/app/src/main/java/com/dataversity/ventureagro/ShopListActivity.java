package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.dataversity.ventureagro.adapter.RouteListAdapter;
import com.dataversity.ventureagro.adapter.ShopListAdapter;
import com.dataversity.ventureagro.model.RoutePojo;
import com.dataversity.ventureagro.model.ShopListPojo;
import com.dataversity.ventureagro.utils.Tools;

import java.util.ArrayList;

public class ShopListActivity extends Activity {
    RecyclerView shop_recyclerview;
    LinearLayoutManager category_layoutManager;
    ShopListAdapter shopListAdapter;
    ShopListPojo shopListPojo;
    private ArrayList<ShopListPojo> routePojoArrayList= new ArrayList<>();
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_list);

        Tools.setSystemBarColor(this, R.color.sub_primary);
        Tools.setSystemBarLight(this);


        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.check_out).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShopListActivity.this, CheckOutActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.btn_continue).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShopListActivity.this, ShopCheckInActivity.class);
                startActivity(intent);
            }
        });

        ShowShopList();

    }

    private void ShowShopList() {

        shop_recyclerview = findViewById(R.id.shop_recyclerview);

        category_layoutManager = new GridLayoutManager(context, 1);
        shopListAdapter = new ShopListAdapter();
        // Set the layout manager
        // and adapter for items
        // of the parent recyclerview

        shopListAdapter.setListContent(routePojoArrayList);
        shop_recyclerview.setAdapter(shopListAdapter);
        shop_recyclerview.setLayoutManager(category_layoutManager);

    }

}