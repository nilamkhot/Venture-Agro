package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.dataversity.ventureagro.network.ApiService;
import com.dataversity.ventureagro.network.RetroInstance;
import com.dataversity.ventureagro.pojo.LoginRequestPojo;
import com.dataversity.ventureagro.pojo.LoginResponsePojo;
import com.dataversity.ventureagro.pojo.SignUpRequestPojo;
import com.dataversity.ventureagro.pojo.SignUpResponsePojo;
import com.dataversity.ventureagro.pojo.User;
import com.dataversity.ventureagro.utils.Shareutil;
import com.dataversity.ventureagro.utils.StaticDialog;
import com.dataversity.ventureagro.utils.Tools;
import com.google.android.material.textfield.TextInputEditText;

public class SignUpActivity extends Activity {
    Context context;
    TextInputEditText name_edit_text, email_edit_text, phone_edit_text, password_edit_text;
    String name_txt, email_txt, phone_txt, password_txt;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        context = this;

        Tools.setSystemBarColor(this, R.color.primary);
        Tools.setSystemBarLight(this);

        name_edit_text = findViewById(R.id.name_edit_text);
        email_edit_text = findViewById(R.id.email_edit_text);
        phone_edit_text = findViewById(R.id.phone_edit_text);
        password_edit_text = findViewById(R.id.password_edit_text);

        findViewById(R.id.sign_up).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                email_txt = email_edit_text.getText().toString().trim();
                password_txt = password_edit_text.getText().toString().trim();
                name_txt = name_edit_text.getText().toString().trim();
                phone_txt = phone_edit_text.getText().toString().trim();

                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if(!email_txt.matches("") && !password_txt.matches("")
                        && !name_txt.matches("") && !phone_txt.matches("")) {

                    if (email_txt.matches(emailPattern)) {

                        SignUpRequestPojo signUpRequestPojo = new SignUpRequestPojo(name_txt, email_txt,password_txt, "91", phone_txt);
                        SetSignUpMethod(signUpRequestPojo);

                    } else {
                        Toast.makeText(getApplicationContext(), "Invalid email address", Toast.LENGTH_SHORT).show();
                    }
                }else {

                    Toast.makeText(getApplicationContext(), "Please Add All Fields.", Toast.LENGTH_SHORT).show();

                }

            }
        });

        findViewById(R.id.sign_in).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void SetSignUpMethod(SignUpRequestPojo signUpRequestPojo) {
        mDialog = ProgressDialog.show(context,"Please wait...", "", true);
        RetroInstance retroInstance = new RetroInstance(context);
        ApiService apiService = retroInstance.getCachedRetrofit().create(ApiService.class);
        Call<SignUpResponsePojo> call = apiService.SetSignUp(signUpRequestPojo);
        call.enqueue(new Callback<SignUpResponsePojo>() {
            @Override
            public void onResponse(Call<SignUpResponsePojo> call, Response<SignUpResponsePojo> response) {
                // Signed in successfully, show authenticated UI.
                if(response.isSuccessful()) {
                   // Toast.makeText(context, response.body().getStatus(), Toast.LENGTH_LONG).show();
                    mDialog.dismiss();

                    User user = new User(response.body().getUser().getRole(), response.body().getUser().get_id(),
                            response.body().getUser().getUsername(), response.body().getUser().getEmail(),
                            response.body().getUser().getPhone_No(),response.body().getUser().getCountryCode());

                    Shareutil.saveId(context, response.body().getUser().get_id());
                    Shareutil.saveSinUpResponse(context, user);
                    Intent intent = new Intent(SignUpActivity.this, VerifyOtpActivity.class);
                    startActivity(intent);
                    finish();

                }else {
                    mDialog.dismiss();
                    Log.d("login_error", response.message());
                    Toast.makeText(context, R.string.try_again, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<SignUpResponsePojo> call, Throwable t) {
                mDialog.dismiss();
                Log.d("login_error", t.toString());
                Toast.makeText(context, R.string.try_again, Toast.LENGTH_LONG).show();
            }
        });
    }

}