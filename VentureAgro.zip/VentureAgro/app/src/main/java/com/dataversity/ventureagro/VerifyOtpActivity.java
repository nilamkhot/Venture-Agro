package com.dataversity.ventureagro;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.dataversity.ventureagro.network.ApiService;
import com.dataversity.ventureagro.network.RetroInstance;
import com.dataversity.ventureagro.pojo.SignUpRequestPojo;
import com.dataversity.ventureagro.pojo.SignUpResponsePojo;
import com.dataversity.ventureagro.pojo.VerifyOtpRequestPojo;
import com.dataversity.ventureagro.utils.Shareutil;
import com.dataversity.ventureagro.utils.StaticDialog;
import com.dataversity.ventureagro.utils.Tools;
import com.gne.www.lib.PinView;

public class VerifyOtpActivity extends Activity {
    Context context;
    PinView pinView;
    String pinview_text;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_otp);
        context = this;

        Tools.setSystemBarColor(this, R.color.primary);
        Tools.setSystemBarLight(this);

        pinView = findViewById(R.id.pinview);

        pinView.getText().toString();

        findViewById(R.id.verify_otp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!pinView.getText().matches("")) {

                    pinview_text = pinView.getText().toString();
                    VerifyOtpRequestPojo verifyOtpRequestPojo = new VerifyOtpRequestPojo(pinView.getText().toString());
                    SetVerifyOTPMethod(verifyOtpRequestPojo);

                }else {

                    Toast.makeText(context, "Please Enter OTP", Toast.LENGTH_LONG).show();

                }
            }
        });

        findViewById(R.id.resend_otp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SetResendOTPMethod();
            }
        });

    }

    private void SetVerifyOTPMethod(VerifyOtpRequestPojo verifyOtpRequestPojo) {
        mDialog = ProgressDialog.show(context,"Please wait...", "", true);

        RetroInstance retroInstance = new RetroInstance(context);
        ApiService apiService = retroInstance.getCachedRetrofit().create(ApiService.class);
        Call<String> call = apiService.SetVerifyOtp(Shareutil.getID(context), verifyOtpRequestPojo);
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                // Signed in successfully, show authenticated UI.
                if(response.isSuccessful()) {
                    mDialog.dismiss();

                    if(response.body().matches("wrong otp!")){

                        Toast.makeText(context, "Wrong OTP Please Try Again.", Toast.LENGTH_LONG).show();
                    }else {
                        // Toast.makeText(context, response.body().getStatus(), Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(VerifyOtpActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }

                }else {
                    mDialog.dismiss();
                    Log.d("login_error", response.message());
                    Toast.makeText(context, R.string.try_again, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                mDialog.dismiss();
                Log.d("login_error", t.toString());
                Toast.makeText(context, R.string.try_again, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void SetResendOTPMethod() {
        mDialog = ProgressDialog.show(context,"Please wait...", "", true);

        RetroInstance retroInstance = new RetroInstance(context);
        ApiService apiService = retroInstance.getCachedRetrofit().create(ApiService.class);
        Call<String> call = apiService.SetResendOtp(Shareutil.getID(context));
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                // Signed in successfully, show authenticated UI.
                if(response.isSuccessful()) {

                    mDialog.dismiss();

                    if(response.body().matches("not send otp!")){
                        Toast.makeText(context, "OTP Not Send Please TRy Again.", Toast.LENGTH_LONG).show();
                    }else {
                        Toast.makeText(context, response.body().toString(), Toast.LENGTH_LONG).show();
                    }


                }else {
                    mDialog.dismiss();
                    Log.d("login_error", response.message());
                    Toast.makeText(context, R.string.try_again, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                mDialog.dismiss();
                Log.d("login_error", t.toString());
                Toast.makeText(context, R.string.try_again, Toast.LENGTH_LONG).show();
            }
        });
    }
}