package com.dataversity.ventureagro.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.model.AttendencePojo;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AttendanceListAdapter extends RecyclerView.Adapter<AttendanceListAdapter.ChildViewHolder> {

    private List<AttendencePojo> ChildItemList;
    Context context;

    // Constuctor
    public AttendanceListAdapter()
    {
    }

    //Setting the arraylist
    public void setListContent(ArrayList<AttendencePojo> ChildItemList){
        this.ChildItemList=ChildItemList;
        notifyItemRangeChanged(0,ChildItemList.size());

    }

    @NonNull
    @Override
    public ChildViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
    {
        // Here we inflate the corresponding
        // layout of the child item
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.attendance_list_child_item, viewGroup, false);

        return new ChildViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChildViewHolder holder, int position)
    {
        // Create an instance of the ChildItem
       /* ServiceListPojo serviceListPojo = ChildItemList.get(position);
        holder.service_name.setText(serviceListPojo.getService_name());
        holder.price.setText(serviceListPojo.getPrice());

        if(serviceListPojo.isCheck()){
            holder.service_name.setChecked(true);
            holder.linear_back.setBackgroundResource(R.drawable.btn_rounded_checknox_checked);
        }else {

            holder.service_name.setChecked(false);
            holder.linear_back.setBackgroundResource(R.drawable.btn_rounded_grey_outline);

        }*/
    }

    @Override
    public int getItemCount()
    {

        // This method returns the number
        // of items we have added
        // in the ChildItemList
        // i.e. the number of instances
        // of the ChildItemList
        // that have been created
      /*  return ChildItemList.size();*/
        return 2;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
    
    // This class is to initialize
    // the Views present
    // in the child RecyclerView
    class ChildViewHolder extends RecyclerView.ViewHolder {

        TextView price;
        CheckBox service_name;
        LinearLayout linear_back;

        ChildViewHolder(View itemView)
        {
            super(itemView);
            /*price = itemView.findViewById(R.id.price);
            service_name = itemView.findViewById(R.id.service_name);
            linear_back = itemView.findViewById(R.id.linear_back);*/
        }
    }
}

