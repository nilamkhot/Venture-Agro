package com.dataversity.ventureagro.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.dataversity.ventureagro.CollectActivity;
import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.model.CollectionMasterPojo;
import com.dataversity.ventureagro.model.OrderHistoryPojo;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

public class CollectionMasterAdapter extends RecyclerView.Adapter<CollectionMasterAdapter.ChildViewHolder> {
    public int mSelectedItem = -1;
    private List<CollectionMasterPojo> ChildItemList;
    Context context;

    // Constuctor
    public CollectionMasterAdapter(Context context)
    {this.context = context;}

    //Setting the arraylist
    public void setListContent(ArrayList<CollectionMasterPojo> ChildItemList){
        this.ChildItemList=ChildItemList;
        notifyItemRangeChanged(0,ChildItemList.size());

    }

    @NonNull
    @Override
    public ChildViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
    {
        // Here we inflate the corresponding
        // layout of the child item
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.collection_master_child_item, viewGroup, false);

        return new ChildViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChildViewHolder holder, int position)
    {
        CollectionMasterPojo collectionMasterPojo = ChildItemList.get(position);
        holder.order_id.setText(collectionMasterPojo.getOrder_id());
        holder.price.setText(collectionMasterPojo.getPrice());
        holder.quantity.setText(collectionMasterPojo.getQuantity());
        holder.date.setText("Date: "+collectionMasterPojo.getDate());
        holder.time.setText("Time: "+collectionMasterPojo.getTime());

        if(collectionMasterPojo.getStatus().matches("collected")){
            holder.collect_now.setText("Collected");
            holder.collect_now.setBackgroundResource(R.drawable.btn_rounded_green);
            holder.collect_now.setTextColor(context.getResources().getColor(R.color.white));
            holder.quantity.setBackgroundColor(context.getResources().getColor(R.color.green_500));
        }else {
            holder.collect_now.setText("Collect Now");
            holder.collect_now.setBackgroundResource(R.drawable.btn_rounded_orange_outline);
            holder.collect_now.setTextColor(context.getResources().getColor(R.color.coloraccent));
            holder.quantity.setBackgroundColor(ContextCompat.getColor(context, R.color.coloraccent));
        }

        holder.collect_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(collectionMasterPojo.getStatus().matches("collected")){
                    Toast.makeText(context, "Collected", Toast.LENGTH_LONG).show();
                }else {
                    Intent intent = new Intent(context, CollectActivity.class);
                    context.startActivity(intent);
                }
            }
        });

    }

    @Override
    public int getItemCount()
    {

        // This method returns the number
        // of items we have added
        // in the ChildItemList
        // i.e. the number of instances
        // of the ChildItemList
        // that have been created
      /*  return ChildItemList.size();*/
        return 2;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
    
    // This class is to initialize
    // the Views present
    // in the child RecyclerView
    class ChildViewHolder extends RecyclerView.ViewHolder {
        TextView order_id, price, quantity, date, time;
        Button collect_now;

        ChildViewHolder(View itemView)
        {
            super(itemView);
            order_id = itemView.findViewById(R.id.order_id);
            price = itemView.findViewById(R.id.price);
            quantity = itemView.findViewById(R.id.quantity);
            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            collect_now = itemView.findViewById(R.id.collect_now);

        }

    }
}

