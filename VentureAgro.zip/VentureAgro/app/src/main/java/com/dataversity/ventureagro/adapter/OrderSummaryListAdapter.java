package com.dataversity.ventureagro.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;

import com.dataversity.ventureagro.OrderDescriptionActivity;
import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.model.ShopListPojo;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class OrderSummaryListAdapter extends RecyclerView.Adapter<OrderSummaryListAdapter.ChildViewHolder> {
    public int mSelectedItem = -1;
    private List<ShopListPojo> ChildItemList;
    Context context;

    // Constuctor
    public OrderSummaryListAdapter(Context context)
    {this.context = context;
    }

    //Setting the arraylist
    public void setListContent(ArrayList<ShopListPojo> ChildItemList){
        this.ChildItemList=ChildItemList;
        notifyItemRangeChanged(0,ChildItemList.size());

    }

    @NonNull
    @Override
    public ChildViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
    {
        // Here we inflate the corresponding
        // layout of the child item
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.order_summary_child_item, viewGroup, false);

        return new ChildViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChildViewHolder holder, int position)
    {
        holder.radio_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, OrderDescriptionActivity.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount()
    {

        // This method returns the number
        // of items we have added
        // in the ChildItemList
        // i.e. the number of instances
        // of the ChildItemList
        // that have been created
      /*  return ChildItemList.size();*/
        return 2;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
    
    // This class is to initialize
    // the Views present
    // in the child RecyclerView
    class ChildViewHolder extends RecyclerView.ViewHolder {

        TextView price;
        CheckBox service_name;
        RadioButton radio_btn;

        ChildViewHolder(View itemView)
        {
            super(itemView);
            radio_btn = itemView.findViewById(R.id.radio_btn);

        }

       /* private void setItem(String item) {
            if(mSelectedItem== getAdapterPosition()) {
                radio_btn.setChecked(true);
            }
            else {
                radio_btn.setChecked(false);
            }

        }*/

    }
}

