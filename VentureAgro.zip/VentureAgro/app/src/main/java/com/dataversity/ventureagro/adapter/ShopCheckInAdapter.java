package com.dataversity.ventureagro.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.model.ShopCheckInPojo;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ShopCheckInAdapter extends RecyclerView.Adapter<ShopCheckInAdapter.ChildViewHolder> {
    public int mSelectedItem = -1;
    private List<ShopCheckInPojo> ChildItemList;
    Context context;

    // Constuctor
    public ShopCheckInAdapter()
    {
    }

    //Setting the arraylist
    public void setListContent(ArrayList<ShopCheckInPojo> ChildItemList){
        this.ChildItemList=ChildItemList;
        notifyItemRangeChanged(0,ChildItemList.size());

    }

    @NonNull
    @Override
    public ChildViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
    {
        // Here we inflate the corresponding
        // layout of the child item
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.shop_checkin_child_item, viewGroup, false);

        return new ChildViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChildViewHolder holder, int position)
    {
        holder.minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int qty = Integer.parseInt(holder.quantity.getText().toString());
                if (qty > 1) {
                    qty--;
                    holder.quantity.setText(qty + "");
                    //result.setQuantity(qty);
                }
            }
        });

        holder.plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int qty = Integer.parseInt(holder.quantity.getText().toString());
                if (qty < 10) {
                    qty++;
                    holder.quantity.setText(qty + "");
                    //result.setQuantity(qty);
                }
            }
        });

    }

    @Override
    public int getItemCount()
    {

        // This method returns the number
        // of items we have added
        // in the ChildItemList
        // i.e. the number of instances
        // of the ChildItemList
        // that have been created
      /*  return ChildItemList.size();*/
        return 2;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
    
    // This class is to initialize
    // the Views present
    // in the child RecyclerView
    class ChildViewHolder extends RecyclerView.ViewHolder {

        ImageView plus, minus;
        TextView quantity;

        ChildViewHolder(View itemView)
        {
            super(itemView);
            plus= itemView.findViewById(R.id.plus);
            minus = itemView.findViewById(R.id.minus);
            quantity = itemView.findViewById(R.id.quantity);
        }

    }
}

