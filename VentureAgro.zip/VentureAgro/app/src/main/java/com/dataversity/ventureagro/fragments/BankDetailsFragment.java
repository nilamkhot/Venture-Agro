package com.dataversity.ventureagro.fragments;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.pojo.PersonalInfoRequestPojo;
import com.dataversity.ventureagro.utils.Shareutil;
import com.google.android.material.textfield.TextInputEditText;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import okhttp3.MultipartBody;

import static android.app.Activity.RESULT_OK;

public class BankDetailsFragment extends Fragment {
    Button previous, next;
    TextInputEditText account_number_edit_text, reeneter_edit_text,ifsc_edit_text,branch_edit_text;
    LinearLayout linear_cancel_cheque, linear_bank_statement;
    String account_number_txt, reenter_number_txt, ifsc_text, branch_txt, cheque_txt, statement_txt;
    ImageView img_cheque, img_statement;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bank_detail, container, false);

        next = view.findViewById(R.id.next);
        previous = view.findViewById(R.id.previous);
        account_number_edit_text = view.findViewById(R.id.account_number_edit_text);
        reeneter_edit_text = view.findViewById(R.id.reeneter_edit_text);
        ifsc_edit_text = view.findViewById(R.id.ifsc_edit_text);
        branch_edit_text = view.findViewById(R.id.branch_edit_text);
        linear_cancel_cheque = view.findViewById(R.id.linear_cancel_cheque);
        linear_bank_statement = view.findViewById(R.id.linear_bank_statement);
        img_cheque = view.findViewById(R.id.img_cheque);
        img_statement = view.findViewById(R.id.img_statement);

        if(!Shareutil.getBankInfo(getContext()).getAccount_number().matches("")){

            account_number_edit_text.setText(Shareutil.getBankInfo(getContext()).getAccount_number());
            reeneter_edit_text.setText(Shareutil.getBankInfo(getContext()).getReenter_accountnumber());
            ifsc_edit_text.setText(Shareutil.getBankInfo(getContext()).getIFSC_code());
            branch_edit_text.setText(Shareutil.getBankInfo(getContext()).getBranch());

            cheque_txt = Shareutil.getBankInfo(getContext()).getCancel_chequephoto();
            statement_txt = Shareutil.getBankInfo(getContext()).getBank_statement_last3month();

            if( !cheque_txt.matches("") ){
                byte[] b = Base64.decode(cheque_txt, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(b, 0, b.length);
                img_cheque.setImageBitmap(bitmap);
            }

            if( !statement_txt.matches("") ){
                byte[] b = Base64.decode(statement_txt, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(b, 0, b.length);
                img_statement.setImageBitmap(bitmap);
            }
        }

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(view).navigateUp();
                //Navigation.findNavController(view).navigate(R.id.action_BankDetailsFragment_to_EmergencyContactFragment);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                account_number_txt = account_number_edit_text.getText().toString().trim();
                reenter_number_txt = reeneter_edit_text.getText().toString().trim();
                ifsc_text = ifsc_edit_text.getText().toString().trim();
                branch_txt = branch_edit_text.getText().toString().trim();

                if(!account_number_txt.matches("") && !reenter_number_txt.matches("")
                        && !ifsc_text.matches("") && !branch_txt.matches("")
                        && !cheque_txt.matches("") && !statement_txt.matches("")) {

                    PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(account_number_txt,reenter_number_txt,ifsc_text,branch_txt,statement_txt,cheque_txt);
                    Shareutil.saveBankInfo(getContext(), personalInfoRequestPojo);
                    Navigation.findNavController(view).navigate(R.id.action_BankDetailsFragment_to_EducationalDetailsFragment);

                }else {

                    Toast.makeText(getContext(), "Please Add All Fields.", Toast.LENGTH_SHORT).show();

                }

            }
        });

        linear_cancel_cheque.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                if(ActivityCompat.checkSelfPermission(getContext(),
                        Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            2000);
                }
                else {
                    Intent cameraIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(cameraIntent, 2000);
                }

            }
        });

        linear_bank_statement.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                if(ActivityCompat.checkSelfPermission(getContext(),
                        Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            4000);
                }
                else {
                    Intent cameraIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(cameraIntent, 4000);
                }

            }
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super method removed
        if (resultCode == RESULT_OK) {

            if (requestCode == 2000) {

                Uri returnUri = data.getData();

                try {

                    Bitmap bitmapImage = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), returnUri);

                    InputStream imageStream = getContext().getContentResolver().openInputStream(returnUri);
                    bitmapImage = BitmapFactory.decodeStream(imageStream);

                    //imageBytes_front = getBytes(imageStream);
                    bitmapImage = getResizedBitmap(bitmapImage, 400);// 400 is for example, replace with desired size

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmapImage.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] b = baos.toByteArray();

                    cheque_txt = Base64.encodeToString(b, Base64.DEFAULT);
                    img_cheque.setImageBitmap(bitmapImage);

                   /* Glide.with(this)
                            .load(bitmapImage)
                            .into(img_front);*/

                } catch (IOException e) {
                    e.printStackTrace();

                }

            }

            if (requestCode == 4000) {

                Uri returnUri = data.getData();

                try {

                    Bitmap bitmapImage = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), returnUri);

                    InputStream imageStream = getContext().getContentResolver().openInputStream(returnUri);
                    bitmapImage = BitmapFactory.decodeStream(imageStream);

                    //imageBytes_back = getBytes(imageStream);
                    bitmapImage = getResizedBitmap(bitmapImage, 400);// 400 is for example, replace with desired size

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmapImage.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] b = baos.toByteArray();
                    statement_txt = Base64.encodeToString(b, Base64.DEFAULT);
                    img_statement.setImageBitmap(bitmapImage);

                   /* Glide.with(this)
                            .load(bitmapImage)
                            .into(img_back);*/

                } catch (IOException e) {
                    e.printStackTrace();

                }

            }

        }
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    public byte[] getBytes(InputStream is) throws IOException {
        ByteArrayOutputStream byteBuff = new ByteArrayOutputStream();

        int buffSize = 1024;
        byte[] buff = new byte[buffSize];

        int len = 0;
        while ((len = is.read(buff)) != -1) {
            byteBuff.write(buff, 0, len);
        }

        return byteBuff.toByteArray();
    }

}