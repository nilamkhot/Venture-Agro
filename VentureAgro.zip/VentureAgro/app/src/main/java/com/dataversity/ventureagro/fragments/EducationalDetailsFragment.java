package com.dataversity.ventureagro.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.pojo.EducationalDetailstPojo;
import com.dataversity.ventureagro.pojo.PersonalInfoRequestPojo;
import com.dataversity.ventureagro.utils.Shareutil;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

public class EducationalDetailsFragment extends Fragment {
    Button previous, next;
    TextInputEditText school_name, school_year, school_state, school_board;
    TextInputEditText college_name, college_year, college_state, college_board;
    TextInputEditText graducation_name, graducation_year, graducation_state, graducation_board;
    TextInputEditText postgraducational_name, postgraducational_year, postgraducational_state, postgraducational_board;
    TextInputEditText degree_name, degree_year, degree_state, degree_board;
    TextInputEditText additional_certificate;

    String school_name_txt, school_year_txt, school_state_txt, school_board_txt = "";
    String college_name_txt, college_year_txt, college_state_txt, college_board_txt = "";
    String graducation_name_txt, graducation_year_txt, graducation_state_txt, graducation_board_txt = "";
    String postgraducational_name_txt, postgraducational_year_txt, postgraducational_state_txt, postgraducational_board_txt = "";
    String degree_name_txt, degree_year_txt, degree_state_txt, degree_board_txt = "";
    String additional_certificate_txt = "";


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_educational_detail, container, false);

        previous = view.findViewById(R.id.previous);
        next = view.findViewById(R.id.next);

        school_name = view.findViewById(R.id.school_name);
        school_year = view.findViewById(R.id.school_year);
        school_state = view.findViewById(R.id.school_state);
        school_board = view.findViewById(R.id.school_board);

        college_name = view.findViewById(R.id.college_name);
        college_year = view.findViewById(R.id.college_year);
        college_state = view.findViewById(R.id.college_state);
        college_board = view.findViewById(R.id.college_board);

        graducation_name = view.findViewById(R.id.graducation_name);
        graducation_year = view.findViewById(R.id.graducation_year);
        graducation_state = view.findViewById(R.id.graducation_state);
        graducation_board = view.findViewById(R.id.graducation_board);

        postgraducational_name = view.findViewById(R.id.postgraducational_name);
        postgraducational_year = view.findViewById(R.id.postgraducational_year);
        postgraducational_state = view.findViewById(R.id.postgraducational_state);
        postgraducational_board = view.findViewById(R.id.postgraducational_board);

        degree_name = view.findViewById(R.id.degree_name);
        degree_year = view.findViewById(R.id.degree_year);
        degree_state = view.findViewById(R.id.degree_state);
        degree_board = view.findViewById(R.id.degree_board);

        additional_certificate = view.findViewById(R.id.additional_certificate);

        if(!Shareutil.getschool(getContext()).get(0).getName().matches("")) {

            school_name.setText(Shareutil.getschool(getContext()).get(0).getName());
            school_year.setText(Shareutil.getschool(getContext()).get(0).getYear());
            school_state.setText(Shareutil.getschool(getContext()).get(0).getState());
            school_board.setText(Shareutil.getschool(getContext()).get(0).getBoard());

        }

        if(!Shareutil.getcollege(getContext()).get(0).getName().matches("")) {

            college_name.setText(Shareutil.getcollege(getContext()).get(0).getName());
            college_year.setText(Shareutil.getcollege(getContext()).get(0).getYear());
            college_state.setText(Shareutil.getcollege(getContext()).get(0).getState());
            college_board.setText(Shareutil.getcollege(getContext()).get(0).getBoard());

        }

        if(!Shareutil.getgraducation(getContext()).get(0).getName().matches("")) {

            graducation_name.setText(Shareutil.getgraducation(getContext()).get(0).getName());
            graducation_year.setText(Shareutil.getgraducation(getContext()).get(0).getYear());
            graducation_state.setText(Shareutil.getgraducation(getContext()).get(0).getState());
            graducation_board.setText(Shareutil.getgraducation(getContext()).get(0).getBoard());

        }

        if(!Shareutil.getpostgraducation(getContext()).get(0).getName().matches("")) {

            postgraducational_name.setText(Shareutil.getpostgraducation(getContext()).get(0).getName());
            postgraducational_year.setText(Shareutil.getpostgraducation(getContext()).get(0).getYear());
            postgraducational_state.setText(Shareutil.getpostgraducation(getContext()).get(0).getState());
            postgraducational_board.setText(Shareutil.getpostgraducation(getContext()).get(0).getBoard());

        }

        if(!Shareutil.getdegree(getContext()).get(0).getName().matches("")) {

            degree_name.setText(Shareutil.getdegree(getContext()).get(0).getName());
            degree_year.setText(Shareutil.getdegree(getContext()).get(0).getYear());
            degree_state.setText(Shareutil.getdegree(getContext()).get(0).getState());
            degree_board.setText(Shareutil.getdegree(getContext()).get(0).getBoard());

        }

        if(!Shareutil.getAdditional(getContext()).matches("")){
            additional_certificate.setText(Shareutil.getAdditional(getContext()));
        }

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(view).navigateUp();
                //Navigation.findNavController(view).navigate(R.id.action_EducationalDetailsFragment_to_BankDetailsFragment);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                school_name_txt = school_name.getText().toString().trim();
                school_year_txt = school_year.getText().toString().trim();
                school_state_txt = school_state.getText().toString().trim();
                school_board_txt = school_board.getText().toString().trim();

                college_name_txt = college_name.getText().toString().trim();
                college_year_txt = college_year.getText().toString().trim();
                college_state_txt = college_state.getText().toString().trim();
                college_board_txt = college_board.getText().toString().trim();

                graducation_name_txt = graducation_name.getText().toString().trim();
                graducation_year_txt = graducation_year.getText().toString().trim();
                graducation_state_txt = graducation_state.getText().toString().trim();
                graducation_board_txt = graducation_board.getText().toString().trim();

                postgraducational_name_txt = postgraducational_name.getText().toString().trim();
                postgraducational_year_txt = postgraducational_year.getText().toString().trim();
                postgraducational_state_txt = postgraducational_state.getText().toString().trim();
                postgraducational_board_txt = postgraducational_board.getText().toString().trim();

                degree_name_txt = degree_name.getText().toString().trim();
                degree_year_txt = degree_year.getText().toString().trim();
                degree_state_txt = degree_state.getText().toString().trim();
                degree_board_txt = degree_board.getText().toString().trim();

                additional_certificate_txt = additional_certificate.getText().toString().trim();

                List<EducationalDetailstPojo> school_pojo = new ArrayList<>();
                school_pojo.add(new EducationalDetailstPojo(school_name_txt, school_year_txt, school_state_txt, school_board_txt));
                Shareutil.saveschool(getContext(), school_pojo);

                List<EducationalDetailstPojo> college_pojo = new ArrayList<>();
                college_pojo.add(new EducationalDetailstPojo(college_name_txt, college_year_txt, college_state_txt, college_board_txt));
                Shareutil.savecollege(getContext(), college_pojo);

                List<EducationalDetailstPojo> graducational_pojo = new ArrayList<>();
                graducational_pojo.add(new EducationalDetailstPojo(graducation_name_txt, graducation_year_txt, graducation_state_txt, graducation_board_txt));
                Shareutil.savegraducation(getContext(), graducational_pojo);

                List<EducationalDetailstPojo> postgraducational_pojo = new ArrayList<>();
                postgraducational_pojo.add(new EducationalDetailstPojo(postgraducational_name_txt, postgraducational_year_txt, postgraducational_state_txt, postgraducational_board_txt));
                Shareutil.savepostgraducation(getContext(), postgraducational_pojo);

                List<EducationalDetailstPojo> degree_pojo = new ArrayList<>();
                degree_pojo.add(new EducationalDetailstPojo(degree_name_txt, degree_year_txt, degree_state_txt, degree_board_txt));
                Shareutil.savedegree(getContext(), degree_pojo);

                Shareutil.saveAdditional(getContext(), additional_certificate_txt);

                //    PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(name_txt,contact_txt,your_relation_txt);
                //    Shareutil.saveContactInfo(getContext(), personalInfoRequestPojo);
                Navigation.findNavController(view).navigate(R.id.action_EducationalDetailsFragment_to_EmploymentHistroyFragment);

            }
        });

        return view;
    }
}