package com.dataversity.ventureagro.fragments;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.pojo.PersonalInfoRequestPojo;
import com.dataversity.ventureagro.utils.Shareutil;
import com.google.android.material.textfield.TextInputEditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import okhttp3.MultipartBody;

public class EmergencyContactFragment extends Fragment {
    Button previous, next;
    TextInputEditText name_edit_text, contact_edit_text,your_relation;
    String name_txt, contact_txt, your_relation_txt;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_emergency_contact, container, false);

        previous = view.findViewById(R.id.previous);
        next = view.findViewById(R.id.next);
        name_edit_text = view.findViewById(R.id.name_edit_text);
        contact_edit_text = view.findViewById(R.id.contact_edit_text);
        your_relation = view.findViewById(R.id.your_relation);

        if(!Shareutil.getContactInfo(getContext()).getEmergency_contactname().matches("")){

            name_edit_text.setText(Shareutil.getContactInfo(getContext()).getEmergency_contactname());
            contact_edit_text.setText(Shareutil.getContactInfo(getContext()).getEmergency_contactnumber());
            your_relation.setText(Shareutil.getContactInfo(getContext()).getRelation());
        }

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigation.findNavController(view).navigate(R.id.action_EmergencyContactFragment_to_VehicleDrivingFragment);
                Navigation.findNavController(view).navigateUp();
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                name_txt = name_edit_text.getText().toString().trim();
                contact_txt = contact_edit_text.getText().toString().trim();
                your_relation_txt = your_relation.getText().toString().trim();


                if(!name_txt.matches("") && !contact_txt.matches("") && !your_relation_txt.matches("")) {

                    PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(name_txt,contact_txt,your_relation_txt);
                    Shareutil.saveContactInfo(getContext(), personalInfoRequestPojo);
                    Navigation.findNavController(view).navigate(R.id.action_EmergencyContactFragment_to_BankDetailsFragment);


                }else {

                    Toast.makeText(getContext(), "Please Add All Fields.", Toast.LENGTH_SHORT).show();

                }

            }
        });

        return view;
    }
}