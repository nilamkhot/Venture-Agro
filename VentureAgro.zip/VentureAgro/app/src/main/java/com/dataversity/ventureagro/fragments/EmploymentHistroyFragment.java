package com.dataversity.ventureagro.fragments;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.dataversity.ventureagro.ApplyForLeave;
import com.dataversity.ventureagro.CheckOutActivity;
import com.dataversity.ventureagro.Dashboard;
import com.dataversity.ventureagro.DocumentsActiviyt;
import com.dataversity.ventureagro.KYCRegistrationActivity;
import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.network.ApiService;
import com.dataversity.ventureagro.network.RetroInstance;
import com.dataversity.ventureagro.pojo.EmployeePojo;
import com.dataversity.ventureagro.pojo.PersonalInfoRequestPojo;
import com.dataversity.ventureagro.pojo.PersonalInfoResponsePojo;
import com.dataversity.ventureagro.utils.Shareutil;
import com.dataversity.ventureagro.utils.StaticDialog;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EmploymentHistroyFragment extends Fragment {
    Button previous, next;
    TextInputEditText company_name, designation, job_description, achievement, skills;
    TextInputEditText company_name1, designation1, job_description1, achievement1, skills1;
    TextInputEditText company_name2, designation2, job_description2, achievement2, skills2;
    String company_name_txt, start_date_txt, end_date_txt, designation_txt, job_description_txt, achievement_txt, skills_txt = "";
    String company_name_txt1, start_date_txt1, end_date_txt1, designation_txt1, job_description_txt1, achievement_txt1, skills_txt1 = "";
    String company_name_txt2, start_date_txt2, end_date_txt2, designation_txt2, job_description_txt2, achievement_txt2, skills_txt2 = "";

    Calendar myCalendar;
    TextView start_date, end_date;
    TextView start_date1, end_date1;
    TextView start_date2, end_date2;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_employment_histroy, container, false);

        previous = view.findViewById(R.id.previous);
        next = view.findViewById(R.id.next);

        company_name = view.findViewById(R.id.company_name);
        start_date = view.findViewById(R.id.start_date);
        end_date = view.findViewById(R.id.end_date);
        designation = view.findViewById(R.id.designation);
        job_description = view.findViewById(R.id.job_description);
        achievement = view.findViewById(R.id.achievement);
        skills = view.findViewById(R.id.skills);

        company_name1 = view.findViewById(R.id.company_name1);
        start_date1 = view.findViewById(R.id.start_date1);
        end_date1 = view.findViewById(R.id.end_date1);
        designation1 = view.findViewById(R.id.designation1);
        job_description1 = view.findViewById(R.id.job_description1);
        achievement1 = view.findViewById(R.id.achievement1);
        skills1 = view.findViewById(R.id.skills1);

        company_name2 = view.findViewById(R.id.company_name2);
        start_date2 = view.findViewById(R.id.start_date2);
        end_date2 = view.findViewById(R.id.end_date2);
        designation2 = view.findViewById(R.id.designation2);
        job_description2 = view.findViewById(R.id.job_description2);
        achievement2 = view.findViewById(R.id.achievement2);
        skills2 = view.findViewById(R.id.skills2);

        if(!Shareutil.getCompanyFirst(getContext()).getCompanyName().matches("")) {

            company_name.setText(Shareutil.getCompanyFirst(getContext()).getCompanyName());
            start_date.setText(Shareutil.getCompanyFirst(getContext()).getStart_date());
            end_date.setText(Shareutil.getCompanyFirst(getContext()).getEnd_date());
            designation.setText(Shareutil.getCompanyFirst(getContext()).getDesignation());
            job_description.setText(Shareutil.getCompanyFirst(getContext()).getJob_Description());
            achievement.setText(Shareutil.getCompanyFirst(getContext()).getAchivement());
            skills.setText(Shareutil.getCompanyFirst(getContext()).getSkills());

        }

        if(!Shareutil.getCompanyFirst(getContext()).getCompanyName().matches("")) {

            company_name.setText(Shareutil.getCompanyFirst(getContext()).getCompanyName());
            start_date.setText(Shareutil.getCompanyFirst(getContext()).getStart_date());
            end_date.setText(Shareutil.getCompanyFirst(getContext()).getEnd_date());
            designation.setText(Shareutil.getCompanyFirst(getContext()).getDesignation());
            job_description.setText(Shareutil.getCompanyFirst(getContext()).getJob_Description());
            achievement.setText(Shareutil.getCompanyFirst(getContext()).getAchivement());
            skills.setText(Shareutil.getCompanyFirst(getContext()).getSkills());

        }

        if(!Shareutil.getCompanySecond(getContext()).getCompanyName().matches("")) {

            company_name1.setText(Shareutil.getCompanyFirst(getContext()).getCompanyName());
            start_date1.setText(Shareutil.getCompanyFirst(getContext()).getStart_date());
            end_date1.setText(Shareutil.getCompanyFirst(getContext()).getEnd_date());
            designation1.setText(Shareutil.getCompanyFirst(getContext()).getDesignation());
            job_description1.setText(Shareutil.getCompanyFirst(getContext()).getJob_Description());
            achievement1.setText(Shareutil.getCompanyFirst(getContext()).getAchivement());
            skills1.setText(Shareutil.getCompanyFirst(getContext()).getSkills());

        }

        if(!Shareutil.getCompanyThird(getContext()).getCompanyName().matches("")) {

            company_name2.setText(Shareutil.getCompanyFirst(getContext()).getCompanyName());
            start_date2.setText(Shareutil.getCompanyFirst(getContext()).getStart_date());
            end_date2.setText(Shareutil.getCompanyFirst(getContext()).getEnd_date());
            designation2.setText(Shareutil.getCompanyFirst(getContext()).getDesignation());
            job_description2.setText(Shareutil.getCompanyFirst(getContext()).getJob_Description());
            achievement2.setText(Shareutil.getCompanyFirst(getContext()).getAchivement());
            skills2.setText(Shareutil.getCompanyFirst(getContext()).getSkills());

        }

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(view).navigateUp();
                //Navigation.findNavController(view).navigate(R.id.action_EmploymentHistroyFragment_to_EducationalDetailsFragment);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                company_name_txt = company_name.getText().toString().trim();
                designation_txt = designation.getText().toString().trim();
                job_description_txt = job_description.getText().toString().trim();
                achievement_txt = achievement.getText().toString().trim();
                skills_txt = skills.getText().toString().trim();
                start_date_txt = start_date.getText().toString();
                end_date_txt = end_date.getText().toString();

                company_name_txt1 = company_name1.getText().toString().trim();
                designation_txt1 = designation1.getText().toString().trim();
                job_description_txt1 = job_description1.getText().toString().trim();
                achievement_txt1 = achievement1.getText().toString().trim();
                skills_txt1 = skills1.getText().toString().trim();
                start_date_txt1 = start_date1.getText().toString();
                end_date_txt1 = end_date1.getText().toString();

                company_name_txt2 = company_name2.getText().toString().trim();
                designation_txt2 = designation2.getText().toString().trim();
                job_description_txt2 = job_description2.getText().toString().trim();
                achievement_txt2 = achievement2.getText().toString().trim();
                skills_txt2 = skills2.getText().toString().trim();
                start_date_txt2 = start_date2.getText().toString();
                end_date_txt2 = end_date2.getText().toString();

                List<EmployeePojo> employeePojoList = new ArrayList<>();
                employeePojoList.add(new EmployeePojo(company_name_txt,designation_txt,job_description_txt,achievement_txt,skills_txt,start_date_txt,end_date_txt));
                employeePojoList.add(new EmployeePojo(company_name_txt1,designation_txt1,job_description_txt1,achievement_txt1,skills_txt1,start_date_txt1,end_date_txt1));
                employeePojoList.add(new EmployeePojo(company_name_txt,designation_txt2,job_description_txt2,achievement_txt2,skills_txt2,start_date_txt2,end_date_txt2));

                Shareutil.saveCompanyFirst(getContext(), employeePojoList.get(0));
                Shareutil.saveCompanySecond(getContext(), employeePojoList.get(1));
                Shareutil.saveCompanyThird(getContext(), employeePojoList.get(2));

                PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(Shareutil.getID(getContext()),
                        Shareutil.getPersonalInfo(getContext()).getUsername(), Shareutil.getPersonalInfo(getContext()).getEmail(),
                        Shareutil.getPersonalInfo(getContext()).getPhone_No(),Shareutil.getPersonalInfo(getContext()).getDate(),
                        Shareutil.getPersonalInfo(getContext()).getCity(),Shareutil.getPersonalInfo(getContext()).getAddress(),
                        Shareutil.getPersonalInfo(getContext()).getGender(),

                        Shareutil.getAdharInfo(getContext()).getAadhar_card_name(),Shareutil.getAdharInfo(getContext()).getDigit_number(),
                        "","",

                        Shareutil.getPanInfo(getContext()).getPAN_card_name(),Shareutil.getPanInfo(getContext()).getPAN_number(),
                        "","",

                        Shareutil.getVehicleInfo(getContext()).getVechile_model(), Shareutil.getVehicleInfo(getContext()).getVechile_number(),
                        Shareutil.getVehicleInfo(getContext()).getDriving_license(), "",

                        Shareutil.getContactInfo(getContext()).getEmergency_contactname(), Shareutil.getContactInfo(getContext()).getEmergency_contactnumber(),
                        Shareutil.getContactInfo(getContext()).getRelation(),

                        Shareutil.getBankInfo(getContext()).getAccount_number(), Shareutil.getBankInfo(getContext()).getReenter_accountnumber(),
                        Shareutil.getBankInfo(getContext()).getIFSC_code(), Shareutil.getBankInfo(getContext()).getBranch(),
                        "","",

                        Shareutil.getschool(getContext()), Shareutil.getcollege(getContext()),
                        Shareutil.getgraducation(getContext()), Shareutil.getpostgraducation(getContext()),
                        Shareutil.getdegree(getContext()),Shareutil.getAdditional(getContext()),

                        employeePojoList);

                SetPersonalInfoMethod(personalInfoRequestPojo);

            }
        });

        //select date
        myCalendar = Calendar.getInstance();
        String myFormat = "dd/MM/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        //for first company
        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                start_date.setText(sdf.format(myCalendar.getTime()));
            }

        };

        start_date.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(getContext(), date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        DatePickerDialog.OnDateSetListener date1 = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                end_date.setText(sdf.format(myCalendar.getTime()));
            }

        };

        end_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(getContext(), date1, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        //for second company
        DatePickerDialog.OnDateSetListener date2 = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                start_date1.setText(sdf.format(myCalendar.getTime()));
            }

        };

        start_date1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(getContext(), date2, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        DatePickerDialog.OnDateSetListener date3 = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                end_date1.setText(sdf.format(myCalendar.getTime()));
            }

        };

        end_date1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(getContext(), date3, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        //for third company
        DatePickerDialog.OnDateSetListener date4 = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                start_date2.setText(sdf.format(myCalendar.getTime()));
            }

        };

        start_date2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(getContext(), date4, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        DatePickerDialog.OnDateSetListener date5 = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                end_date2.setText(sdf.format(myCalendar.getTime()));
            }

        };

        end_date2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(getContext(), date5, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        return view;
    }

    private void SetPersonalInfoMethod(PersonalInfoRequestPojo personalInfoRequestPojo) {
        StaticDialog.setDialog(getContext()).show();
        RetroInstance retroInstance = new RetroInstance(getContext());
        ApiService apiService = retroInstance.getCachedRetrofit().create(ApiService.class);
        Call<PersonalInfoResponsePojo> call = apiService.SetPersonalnfo(personalInfoRequestPojo);
        call.enqueue(new Callback<PersonalInfoResponsePojo>() {
            @Override
            public void onResponse(Call<PersonalInfoResponsePojo> call, Response<PersonalInfoResponsePojo> response) {
                // Signed in successfully, show authenticated UI.
                if(response.isSuccessful()) {
                    Toast.makeText(getContext(), response.body().getStatus(), Toast.LENGTH_LONG).show();
                    StaticDialog.setDialog(getContext()).cancel();

                    Intent intent = new Intent(getContext(), Dashboard.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    getActivity().finish();

                }else {
                    StaticDialog.setDialog(getContext()).cancel();
                    Log.d("login_error", response.message());
                    Toast.makeText(getContext(), R.string.try_again, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<PersonalInfoResponsePojo> call, Throwable t) {
                StaticDialog.setDialog(getContext()).cancel();
                Log.d("login_error", t.toString());
                Toast.makeText(getContext(), R.string.try_again, Toast.LENGTH_LONG).show();
            }
        });
    }

}