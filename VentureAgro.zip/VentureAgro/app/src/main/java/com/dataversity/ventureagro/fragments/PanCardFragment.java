package com.dataversity.ventureagro.fragments;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.pojo.PersonalInfoRequestPojo;
import com.dataversity.ventureagro.utils.Shareutil;
import com.google.android.material.textfield.TextInputEditText;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;
import okhttp3.MultipartBody;

import static android.app.Activity.RESULT_OK;

public class PanCardFragment extends Fragment {
    Button previous, next,upload_back_photo,upload_front_photo;
    TextInputEditText name_edit_text, number_edit_text;
    String name_txt, number_txt, pan_front, pan_back;
    byte[] imageBytes_front;
    byte[] imageBytes_back;
    ImageView img_front, img_back;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pancard, container, false);

        previous = view.findViewById(R.id.previous);
        next = view.findViewById(R.id.next);
        img_front = view.findViewById(R.id.img_selfi);
        img_back = view.findViewById(R.id.img_pan);
        upload_front_photo = view.findViewById(R.id.upload_front_photo);
        upload_back_photo = view.findViewById(R.id.upload_back_photo);
        name_edit_text = view.findViewById(R.id.name_edit_text);
        number_edit_text = view.findViewById(R.id.number_edit_text);

        if(!Shareutil.getPanInfo(getContext()).getPAN_card_name().matches("")){

            name_edit_text.setText(Shareutil.getPanInfo(getContext()).getPAN_card_name());
            number_edit_text.setText(Shareutil.getPanInfo(getContext()).getPAN_number());
            pan_front = Shareutil.getPanInfo(getContext()).getPan_cardphoto_selfi();
            pan_back = Shareutil.getPanInfo(getContext()).getPAN_card_photo();

            if( !pan_front.matches("") ){
                byte[] b = Base64.decode(pan_front, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(b, 0, b.length);
                img_front.setImageBitmap(bitmap);
            }

            if( !pan_back.matches("") ){
                byte[] b = Base64.decode(pan_back, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(b, 0, b.length);
                img_back.setImageBitmap(bitmap);
            }
        }

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigation.findNavController(view).navigate(R.id.action_PanCardFragment_to_AdharCardFragment);
                Navigation.findNavController(view).navigateUp();
               /* FragmentManager fm = getActivity().getSupportFragmentManager();
                fm.popBackStack();*/
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                name_txt = name_edit_text.getText().toString().trim();
                number_txt = number_edit_text.getText().toString().trim();

                MultipartBody.Part body_front = null;
                MultipartBody.Part body_back = null;
                String front_name = "adhar_front_"+ Shareutil.getID(getContext());
                String back_name = "adhar_back_"+Shareutil.getID(getContext());

               /*// if(imageBytes_front.length > 0) {
                    RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpeg"), imageBytes_front);

                    body_front = MultipartBody.Part.createFormData("image", front_name + ".jpg", requestFile);
              //  }

               // if(imageBytes_back.length > 0) {
                    RequestBody requestFile1 = RequestBody.create(MediaType.parse("image/jpeg"), imageBytes_back);

                    body_back = MultipartBody.Part.createFormData("image", back_name + ".jpg", requestFile1);
               // }
*/
                if(!number_txt.matches("") && !name_txt.matches("")
                        && !pan_front.matches("") && !pan_back.matches("")) {

                        // if (imageBytes_front.length > 0 && imageBytes_back.length > 0){

                        PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(Shareutil.getID(getContext()),name_txt,number_txt,pan_front,pan_back);
                        Shareutil.savePanCardInfo(getContext(), personalInfoRequestPojo);
                        Navigation.findNavController(view).navigate(R.id.action_PanCardFragment_to_VehicleDrivingFragment);

                        /*}else {
                            Toast.makeText(getContext(), "Please Add Photo", Toast.LENGTH_SHORT).show();
                        }*/

                }else {

                    Toast.makeText(getContext(), "Please Add All Fields.", Toast.LENGTH_SHORT).show();

                }


            }
        });

        upload_front_photo.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                if(ActivityCompat.checkSelfPermission(getContext(),
                        Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            2000);
                }
                else {
                    Intent cameraIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(cameraIntent, 2000);
                }

            }
        });

        upload_back_photo.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                if(ActivityCompat.checkSelfPermission(getContext(),
                        Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            4000);
                }
                else {
                    Intent cameraIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(cameraIntent, 4000);
                }

            }
        });


        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super method removed
        if (resultCode == RESULT_OK) {

            if (requestCode == 2000) {

                Uri returnUri = data.getData();

                try {

                    Bitmap bitmapImage = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), returnUri);

                    InputStream imageStream = getContext().getContentResolver().openInputStream(returnUri);
                    bitmapImage = BitmapFactory.decodeStream(imageStream);

                    imageBytes_front = getBytes(imageStream);
                    bitmapImage = getResizedBitmap(bitmapImage, 400);// 400 is for example, replace with desired size

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmapImage.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] b = baos.toByteArray();

                    pan_front = Base64.encodeToString(b, Base64.DEFAULT);
                    img_front.setImageBitmap(bitmapImage);

                   /* Glide.with(this)
                            .load(bitmapImage)
                            .into(img_front);*/

                } catch (IOException e) {
                    e.printStackTrace();

                }

            }

            if (requestCode == 4000) {

                Uri returnUri = data.getData();

                try {

                    Bitmap bitmapImage = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), returnUri);

                    InputStream imageStream = getContext().getContentResolver().openInputStream(returnUri);
                    bitmapImage = BitmapFactory.decodeStream(imageStream);

                    imageBytes_back = getBytes(imageStream);
                    bitmapImage = getResizedBitmap(bitmapImage, 400);// 400 is for example, replace with desired size

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmapImage.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] b = baos.toByteArray();
                    pan_back = Base64.encodeToString(b, Base64.DEFAULT);
                    img_back.setImageBitmap(bitmapImage);

                   /* Glide.with(this)
                            .load(bitmapImage)
                            .into(img_back);*/

                } catch (IOException e) {
                    e.printStackTrace();

                }

            }

        }
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    public byte[] getBytes(InputStream is) throws IOException {
        ByteArrayOutputStream byteBuff = new ByteArrayOutputStream();

        int buffSize = 1024;
        byte[] buff = new byte[buffSize];

        int len = 0;
        while ((len = is.read(buff)) != -1) {
            byteBuff.write(buff, 0, len);
        }

        return byteBuff.toByteArray();
    }

}