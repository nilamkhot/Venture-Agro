package com.dataversity.ventureagro.fragments;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.pojo.PersonalInfoRequestPojo;
import com.dataversity.ventureagro.utils.Shareutil;
import com.google.android.material.textfield.TextInputEditText;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import okhttp3.MultipartBody;

import static android.app.Activity.RESULT_OK;

public class VehicleDrivingFragment extends Fragment {
    Button previous, next,upload_front_photo;
    TextInputEditText vehicle_model_edit_text, vehicle_number_edit_text,license_number_edit_text;
    String vehicle_model_txt, vehicle_number_txt, license_number_txt,photo_txt;
    byte[] imageBytes_front;
    ImageView license_photo;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_vehicle_driving, container, false);

        previous = view.findViewById(R.id.previous);
        next = view.findViewById(R.id.next);
        vehicle_model_edit_text = view.findViewById(R.id.vehicle_model_edit_text);
        vehicle_number_edit_text = view.findViewById(R.id.vehicle_number_edit_text);
        license_number_edit_text = view.findViewById(R.id.license_number_edit_text);
        license_photo = view.findViewById(R.id.license_photo);
        upload_front_photo = view.findViewById(R.id.upload_front_photo);

        if(!Shareutil.getVehicleInfo(getContext()).getVechile_model().matches("")){

            vehicle_model_edit_text.setText(Shareutil.getVehicleInfo(getContext()).getVechile_model());
            vehicle_number_edit_text.setText(Shareutil.getVehicleInfo(getContext()).getVechile_number());
            license_number_edit_text.setText(Shareutil.getVehicleInfo(getContext()).getDriving_license());
            photo_txt = Shareutil.getVehicleInfo(getContext()).getDriving_license_photo();

            if( !photo_txt.matches("") ){
                byte[] b = Base64.decode(photo_txt, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(b, 0, b.length);
                license_photo.setImageBitmap(bitmap);
            }

        }

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigation.findNavController(view).navigate(R.id.action_VehicleDrivingFragment_to_PanCardFragment);
                Navigation.findNavController(view).navigateUp();
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                vehicle_model_txt = vehicle_model_edit_text.getText().toString().trim();
                vehicle_number_txt = vehicle_number_edit_text.getText().toString().trim();
                license_number_txt = license_number_edit_text.getText().toString().trim();

                MultipartBody.Part body_front = null;
                MultipartBody.Part body_back = null;
                String front_name = "adhar_front_"+ Shareutil.getID(getContext());

               /*// if(imageBytes_front.length > 0) {
                    RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpeg"), imageBytes_front);

                    body_front = MultipartBody.Part.createFormData("image", front_name + ".jpg", requestFile);
              //  }

               // if(imageBytes_back.length > 0) {
                    RequestBody requestFile1 = RequestBody.create(MediaType.parse("image/jpeg"), imageBytes_back);

                    body_back = MultipartBody.Part.createFormData("image", back_name + ".jpg", requestFile1);
               // }
*/
                if(!vehicle_model_txt.matches("") && !vehicle_number_txt.matches("")
                        && !license_number_txt.matches("") && !photo_txt.matches("")) {

                    // if (imageBytes_front.length > 0 && imageBytes_back.length > 0){

                    PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(0,vehicle_model_txt,vehicle_number_txt,license_number_txt,photo_txt);
                    Shareutil.saveVehicledInfo(getContext(), personalInfoRequestPojo);
                    Navigation.findNavController(view).navigate(R.id.action_VehicleDrivingFragment_to_EmergencyContactFragment);

                        /*}else {
                            Toast.makeText(getContext(), "Please Add Photo", Toast.LENGTH_SHORT).show();
                        }*/

                }else {

                    Toast.makeText(getContext(), "Please Add All Fields.", Toast.LENGTH_SHORT).show();

                }

            }
        });


        upload_front_photo.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                if(ActivityCompat.checkSelfPermission(getContext(),
                        Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            2000);
                }
                else {
                    Intent cameraIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(cameraIntent, 2000);
                }

            }
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super method removed
        if (resultCode == RESULT_OK) {

            if (requestCode == 2000) {

                Uri returnUri = data.getData();

                try {

                    Bitmap bitmapImage = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), returnUri);

                    InputStream imageStream = getContext().getContentResolver().openInputStream(returnUri);
                    bitmapImage = BitmapFactory.decodeStream(imageStream);

                    imageBytes_front = getBytes(imageStream);
                    bitmapImage = getResizedBitmap(bitmapImage, 400);// 400 is for example, replace with desired size

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmapImage.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] b = baos.toByteArray();

                    photo_txt = Base64.encodeToString(b, Base64.DEFAULT);

                    license_photo.setImageBitmap(bitmapImage);

                } catch (IOException e) {
                    e.printStackTrace();

                }

            }

        }
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    public byte[] getBytes(InputStream is) throws IOException {
        ByteArrayOutputStream byteBuff = new ByteArrayOutputStream();

        int buffSize = 1024;
        byte[] buff = new byte[buffSize];

        int len = 0;
        while ((len = is.read(buff)) != -1) {
            byteBuff.write(buff, 0, len);
        }

        return byteBuff.toByteArray();
    }

}