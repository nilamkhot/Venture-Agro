package com.dataversity.ventureagro.model;

public class CollectionMasterPojo {
    String order_id;
    String price;
    String quantity;
    String date;
    String time;
    String status;


    public CollectionMasterPojo(String order_id, String price, String quantity, String date, String time, String status) {
        this.order_id = order_id;
        this.price = price;
        this.quantity = quantity;
        this.date = date;
        this.time = time;
        this.status = status;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
