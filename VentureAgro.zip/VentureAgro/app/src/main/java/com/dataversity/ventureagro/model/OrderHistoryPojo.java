package com.dataversity.ventureagro.model;

public class OrderHistoryPojo {
    String shop_name;
    String address;

    public OrderHistoryPojo() {
    }

    public String getShop_name() {
        return shop_name;
    }

    public void setShop_name(String shop_name) {
        this.shop_name = shop_name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
