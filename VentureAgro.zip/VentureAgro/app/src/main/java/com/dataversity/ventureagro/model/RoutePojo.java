package com.dataversity.ventureagro.model;

public class RoutePojo {
    String leaving_from;
    String going_to;

    public RoutePojo() {
    }

    public String getLeaving_from() {
        return leaving_from;
    }

    public void setLeaving_from(String leaving_from) {
        this.leaving_from = leaving_from;
    }

    public String getGoing_to() {
        return going_to;
    }

    public void setGoing_to(String going_to) {
        this.going_to = going_to;
    }
}
