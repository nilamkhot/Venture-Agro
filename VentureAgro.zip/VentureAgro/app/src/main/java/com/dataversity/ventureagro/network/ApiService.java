package com.dataversity.ventureagro.network;

import com.dataversity.ventureagro.pojo.LoginRequestPojo;
import com.dataversity.ventureagro.pojo.LoginResponsePojo;
import com.dataversity.ventureagro.pojo.PersonalInfoRequestPojo;
import com.dataversity.ventureagro.pojo.PersonalInfoResponsePojo;
import com.dataversity.ventureagro.pojo.SignUpRequestPojo;
import com.dataversity.ventureagro.pojo.SignUpResponsePojo;
import com.dataversity.ventureagro.pojo.VerifyOtpRequestPojo;

import java.util.List;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;


public interface ApiService {

    @POST("api/login")
    Call<LoginResponsePojo> SetLogin(@Body LoginRequestPojo loginRequestPojo);

    @POST("api/sign-up")
    Call<SignUpResponsePojo> SetSignUp(@Body SignUpRequestPojo signUpRequestPojo);

    @POST("api/users/{userId}/verify")
    Call<String> SetVerifyOtp(@Path("userId") String userId, @Body VerifyOtpRequestPojo verifyOtpRequestPojo);

    @POST("api/users/{userId}/resend")
    Call<String> SetResendOtp(@Path("userId") String userId);

    @POST("api/addkyc")
    Call<PersonalInfoResponsePojo> SetPersonalnfo(@Body PersonalInfoRequestPojo personalInfoRequestPojo);

   /* @POST("token")
    @FormUrlEncoded
    Call<TokenPojo> getToken(@Field("grant_type") String grant_type,
                             @Field("username") String username,
                             @Field("password") String password);*/

    /*@POST("api/login")
    Call<LoginResponsePojo> SetLogin(@Body LoginRequestPojo loginRequestPojo);

    @POST("api/register-user")
    Call<RegisterUserResponsePojo> SetAddUser(@Body RegisterUserRequestPojo registerUserRequestPojo);

    @GET("api/franchisetotalwashers")
    Call<List<FranchiseWasherResponsePojo>> GetFranchiseWasher(@Body FranchiseWasherRequestPojo franchiseWasherRequestPojo);

    @GET("api/submitfranchiseservice")
    Call<List<ManageServiceResponsePojo>> GetManageService(@Body ManageServiceRequestPojo manageServiceRequestPojo);

    @GET("api/addfranchiseservice")
    Call<List<AddServiceResponsePojo>> PostAddService(@Body List<AddServiceResponsePojo> addServiceResponsePojoList);
*/
    /*@POST("api/services/storycategory")
    Call<List<CategoryModel>> getcategoryList();

    @POST("api/services/catandstory")
    Call<List<ParentItem>> getRecentList();

    @POST("api/services/getstory")
    @FormUrlEncoded
    Call<List<StoryListModel>> getStoryList(@Field("cat_id") int cat_id);

    @GET("public/data/{token}")
    Call<List<Shlokpojo>> getshlok(@Path("token") String token);

    @POST("api/services/addnewstory")
    @FormUrlEncoded
    Call<String> sendStory(@Field("cat_id") int cat_id,
                           @Field("u_id") int u_id,
                           @Field("title") String title_text,
                           @Field("content") String content_text,
                           @Field("image") MultipartBody.Part body,
                           @Field("part") int part,
                           @Field("draft") int draft);
*/
}
