package com.dataversity.ventureagro.network;

public class Credentials {

    public static String grant_type = "password";
    public static String username = "ITIC-00000001";
    public static String password = "Rajpal@123";
}
