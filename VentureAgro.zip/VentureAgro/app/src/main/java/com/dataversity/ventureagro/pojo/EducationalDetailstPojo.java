package com.dataversity.ventureagro.pojo;

import com.google.gson.annotations.SerializedName;

public class EducationalDetailstPojo {
    @SerializedName("Name")
    private String Name;

    @SerializedName("Year")
    private String Year;

    @SerializedName("State")
    private String State;

    @SerializedName("Board")
    private String Board;

    public EducationalDetailstPojo(String name, String year, String state, String board) {
        Name = name;
        Year = year;
        State = state;
        Board = board;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getBoard() {
        return Board;
    }

    public void setBoard(String board) {
        Board = board;
    }
}

