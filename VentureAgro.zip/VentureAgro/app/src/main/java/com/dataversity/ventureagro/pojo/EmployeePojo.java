package com.dataversity.ventureagro.pojo;

import com.google.gson.annotations.SerializedName;

public class EmployeePojo {
    @SerializedName("CompanyName")
    private String CompanyName;

    @SerializedName("start_date")
    private String start_date;

    @SerializedName("end_date")
    private String end_date;

    @SerializedName("Designation")
    private String Designation;

    @SerializedName("Job_Description")
    private String Job_Description;

    @SerializedName("Achivement")
    private String Achivement;

    @SerializedName("Skills")
    private String Skills;

    public EmployeePojo(String companyName, String start_date, String end_date, String designation, String job_Description, String achivement, String skills) {
        CompanyName = companyName;
        this.start_date = start_date;
        this.end_date = end_date;
        Designation = designation;
        Job_Description = job_Description;
        Achivement = achivement;
        Skills = skills;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public void setCompanyName(String companyName) {
        CompanyName = companyName;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String designation) {
        Designation = designation;
    }

    public String getJob_Description() {
        return Job_Description;
    }

    public void setJob_Description(String job_Description) {
        Job_Description = job_Description;
    }

    public String getAchivement() {
        return Achivement;
    }

    public void setAchivement(String achivement) {
        Achivement = achivement;
    }

    public String getSkills() {
        return Skills;
    }

    public void setSkills(String skills) {
        Skills = skills;
    }


}

