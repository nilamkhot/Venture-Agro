package com.dataversity.ventureagro.pojo;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import retrofit2.http.Body;

public class PersonalInfoRequestPojo {

    int idd = 0;

    @SerializedName("userId")
    private String userId;

    @SerializedName("username")
    private String username;

    @SerializedName("Email")
    private String Email;

    @SerializedName("Phone_No")
    private String Phone_No;

    @SerializedName("Date")
    private String date;

    @SerializedName("City")
    private String city;

    @SerializedName("Complete_Address")
    private String address;

    @SerializedName("Gender")
    private String Gender;

    @SerializedName("Aadhar_card_name")
    private String Aadhar_card_name;

    @SerializedName("digit_number")
    private String digit_number;

    @SerializedName("Front_side_photo")
    private String Front_side_photo;

    @SerializedName("Back_side_photo")
    private String Back_side_photo;

    @SerializedName("PAN_card_name")
    private String PAN_card_name;

    @SerializedName("PAN_number")
    private String PAN_number;

    @SerializedName("Pan_cardphoto_selfi")
    private String Pan_cardphoto_selfi;

    @SerializedName("PAN_card_photo")
    private String PAN_card_photo;

    @SerializedName("Vechile_model")
    private String Vechile_model;

    @SerializedName("Vechile_number")
    private String Vechile_number;

    @SerializedName("Driving_license")
    private String Driving_license;

    @SerializedName("Driving_license_photo")
    private String Driving_license_photo;

    @SerializedName("Emergency_contactname")
    private String Emergency_contactname;

    @SerializedName("Emergency_contactnumber")
    private String Emergency_contactnumber;

    @SerializedName("relation")
    private String relation;

    @SerializedName("Account_number")
    private String Account_number;

    @SerializedName("Reenter_accountnumber")
    private String Reenter_accountnumber;

    @SerializedName("IFSC_code")
    private String IFSC_code;

    @SerializedName("Branch")
    private String Branch;

    @SerializedName("Bank_statement_last3month")
    private String Bank_statement_last3month;

    @SerializedName("Cancel_chequephoto")
    private String Cancel_chequephoto;

    @SerializedName("Primary")
    private List<EducationalDetailstPojo> Primary;

    @SerializedName("College")
    private List<EducationalDetailstPojo> College;

    @SerializedName("Graduction")
    private List<EducationalDetailstPojo> Graduction;

    @SerializedName("Post_Graduction")
    private List<EducationalDetailstPojo> Post_Graduction;

    @SerializedName("Degree_Diploma")
    private List<EducationalDetailstPojo> Degree_Diploma;

    @SerializedName("Additional_certificate")
    private String Additional_certificate;

    @SerializedName("Employee")
    private List<EmployeePojo> Employee;

    //for perosnal info
    public PersonalInfoRequestPojo(String userId, String username, String email, String Phone_No, String date, String city, String address, String Gender) {
        this.userId = userId;
        this.username = username;
        Email = email;
        this.Phone_No = Phone_No;
        this.date = date;
        this.city = city;
        this.address = address;
        this.Gender = Gender;
    }

    //for adhar_card details
    public PersonalInfoRequestPojo(String aadhar_card_name, String digit_number, String front_side_photo, String back_side_photo) {
        Aadhar_card_name = aadhar_card_name;
        this.digit_number = digit_number;
        Front_side_photo = front_side_photo;
        Back_side_photo = back_side_photo;
    }

    //for pan card details
    public PersonalInfoRequestPojo(String userId, String PAN_card_name, String PAN_number, String pan_cardphoto_selfi, String PAN_card_photo) {
        this.userId = userId;
        this.PAN_card_name = PAN_card_name;
        this.PAN_number = PAN_number;
        Pan_cardphoto_selfi = pan_cardphoto_selfi;
        this.PAN_card_photo = PAN_card_photo;
    }

    //for vehicle details
    public PersonalInfoRequestPojo(int idd, String vechile_model, String vechile_number, String driving_license, String driving_license_photo) {
        this.idd = idd;
        Vechile_model = vechile_model;
        Vechile_number = vechile_number;
        Driving_license = driving_license;
        Driving_license_photo = driving_license_photo;
    }

    //for contact details
    public PersonalInfoRequestPojo(String emergency_contactname, String emergency_contactnumber, String relation) {
        Emergency_contactname = emergency_contactname;
        Emergency_contactnumber = emergency_contactnumber;
        this.relation = relation;
    }

    //for bank details
    public PersonalInfoRequestPojo(String account_number, String reenter_accountnumber, String IFSC_code, String branch, String bank_statement_last3month, String cancel_chequephoto) {
        Account_number = account_number;
        Reenter_accountnumber = reenter_accountnumber;
        this.IFSC_code = IFSC_code;
        Branch = branch;
        Bank_statement_last3month = bank_statement_last3month;
        Cancel_chequephoto = cancel_chequephoto;
    }

    //for education
    public PersonalInfoRequestPojo(List<EducationalDetailstPojo> primary, List<EducationalDetailstPojo> college, List<EducationalDetailstPojo> graduction, List<EducationalDetailstPojo> post_Graduction, List<EducationalDetailstPojo> degree_Diploma, String additional_certificate) {
        Primary = primary;
        College = college;
        Graduction = graduction;
        Post_Graduction = post_Graduction;
        Degree_Diploma = degree_Diploma;
        Additional_certificate = additional_certificate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhone_No() {
        return Phone_No;
    }

    public void setPhone_No(String phone_No) {
        Phone_No = phone_No;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getAadhar_card_name() {
        return Aadhar_card_name;
    }

    public void setAadhar_card_name(String aadhar_card_name) {
        Aadhar_card_name = aadhar_card_name;
    }

    public String getDigit_number() {
        return digit_number;
    }

    public void setDigit_number(String digit_number) {
        this.digit_number = digit_number;
    }

    public String getFront_side_photo() {
        return Front_side_photo;
    }

    public void setFront_side_photo(String front_side_photo) {
        Front_side_photo = front_side_photo;
    }

    public String getBack_side_photo() {
        return Back_side_photo;
    }

    public void setBack_side_photo(String back_side_photo) {
        Back_side_photo = back_side_photo;
    }

    public String getPAN_card_name() {
        return PAN_card_name;
    }

    public void setPAN_card_name(String PAN_card_name) {
        this.PAN_card_name = PAN_card_name;
    }

    public String getPAN_number() {
        return PAN_number;
    }

    public void setPAN_number(String PAN_number) {
        this.PAN_number = PAN_number;
    }

    public String getPan_cardphoto_selfi() {
        return Pan_cardphoto_selfi;
    }

    public void setPan_cardphoto_selfi(String pan_cardphoto_selfi) {
        Pan_cardphoto_selfi = pan_cardphoto_selfi;
    }

    public String getPAN_card_photo() {
        return PAN_card_photo;
    }

    public void setPAN_card_photo(String PAN_card_photo) {
        this.PAN_card_photo = PAN_card_photo;
    }

    public int getIdd() {
        return idd;
    }

    public void setIdd(int idd) {
        this.idd = idd;
    }

    public String getVechile_model() {
        return Vechile_model;
    }

    public void setVechile_model(String vechile_model) {
        Vechile_model = vechile_model;
    }

    public String getVechile_number() {
        return Vechile_number;
    }

    public void setVechile_number(String vechile_number) {
        Vechile_number = vechile_number;
    }

    public String getDriving_license() {
        return Driving_license;
    }

    public void setDriving_license(String driving_license) {
        Driving_license = driving_license;
    }

    public String getDriving_license_photo() {
        return Driving_license_photo;
    }

    public void setDriving_license_photo(String driving_license_photo) {
        Driving_license_photo = driving_license_photo;
    }

    public String getEmergency_contactname() {
        return Emergency_contactname;
    }

    public void setEmergency_contactname(String emergency_contactname) {
        Emergency_contactname = emergency_contactname;
    }

    public String getEmergency_contactnumber() {
        return Emergency_contactnumber;
    }

    public void setEmergency_contactnumber(String emergency_contactnumber) {
        Emergency_contactnumber = emergency_contactnumber;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public String getAccount_number() {
        return Account_number;
    }

    public void setAccount_number(String account_number) {
        Account_number = account_number;
    }

    public String getReenter_accountnumber() {
        return Reenter_accountnumber;
    }

    public void setReenter_accountnumber(String reenter_accountnumber) {
        Reenter_accountnumber = reenter_accountnumber;
    }

    public String getIFSC_code() {
        return IFSC_code;
    }

    public void setIFSC_code(String IFSC_code) {
        this.IFSC_code = IFSC_code;
    }

    public String getBranch() {
        return Branch;
    }

    public void setBranch(String branch) {
        Branch = branch;
    }

    public String getBank_statement_last3month() {
        return Bank_statement_last3month;
    }

    public void setBank_statement_last3month(String bank_statement_last3month) {
        Bank_statement_last3month = bank_statement_last3month;
    }

    public String getCancel_chequephoto() {
        return Cancel_chequephoto;
    }

    public void setCancel_chequephoto(String cancel_chequephoto) {
        Cancel_chequephoto = cancel_chequephoto;
    }

    public List<EducationalDetailstPojo> getPrimary() {
        return Primary;
    }

    public void setPrimary(List<EducationalDetailstPojo> primary) {
        Primary = primary;
    }

    public List<EducationalDetailstPojo> getCollege() {
        return College;
    }

    public void setCollege(List<EducationalDetailstPojo> college) {
        College = college;
    }

    public List<EducationalDetailstPojo> getGraduction() {
        return Graduction;
    }

    public void setGraduction(List<EducationalDetailstPojo> graduction) {
        Graduction = graduction;
    }

    public List<EducationalDetailstPojo> getPost_Graduction() {
        return Post_Graduction;
    }

    public void setPost_Graduction(List<EducationalDetailstPojo> post_Graduction) {
        Post_Graduction = post_Graduction;
    }

    public List<EducationalDetailstPojo> getDegree_Diploma() {
        return Degree_Diploma;
    }

    public void setDegree_Diploma(List<EducationalDetailstPojo> degree_Diploma) {
        Degree_Diploma = degree_Diploma;
    }

    public String getAdditional_certificate() {
        return Additional_certificate;
    }

    public void setAdditional_certificate(String additional_certificate) {
        Additional_certificate = additional_certificate;
    }

    public List<EmployeePojo> getEmployee() {
        return Employee;
    }

    public void setEmployee(List<EmployeePojo> employee) {
        Employee = employee;
    }

    // all data
    public PersonalInfoRequestPojo(String userId, String username, String email, String phone_No, String date, String city, String address, String gender, String aadhar_card_name, String digit_number, String front_side_photo, String back_side_photo, String PAN_card_name, String PAN_number, String pan_cardphoto_selfi, String PAN_card_photo, String vechile_model, String vechile_number, String driving_license, String driving_license_photo, String emergency_contactname, String emergency_contactnumber, String relation, String account_number, String reenter_accountnumber, String IFSC_code, String branch, String bank_statement_last3month, String cancel_chequephoto, List<EducationalDetailstPojo> primary, List<EducationalDetailstPojo> college, List<EducationalDetailstPojo> graduction, List<EducationalDetailstPojo> post_Graduction, List<EducationalDetailstPojo> degree_Diploma, String additional_certificate, List<EmployeePojo> employee) {
        this.userId = userId;
        this.username = username;
        Email = email;
        Phone_No = phone_No;
        this.date = date;
        this.city = city;
        this.address = address;
        Gender = gender;
        Aadhar_card_name = aadhar_card_name;
        this.digit_number = digit_number;
        Front_side_photo = front_side_photo;
        Back_side_photo = back_side_photo;
        this.PAN_card_name = PAN_card_name;
        this.PAN_number = PAN_number;
        Pan_cardphoto_selfi = pan_cardphoto_selfi;
        this.PAN_card_photo = PAN_card_photo;
        Vechile_model = vechile_model;
        Vechile_number = vechile_number;
        Driving_license = driving_license;
        Driving_license_photo = driving_license_photo;
        Emergency_contactname = emergency_contactname;
        Emergency_contactnumber = emergency_contactnumber;
        this.relation = relation;
        Account_number = account_number;
        Reenter_accountnumber = reenter_accountnumber;
        this.IFSC_code = IFSC_code;
        Branch = branch;
        Bank_statement_last3month = bank_statement_last3month;
        Cancel_chequephoto = cancel_chequephoto;
        Primary = primary;
        College = college;
        Graduction = graduction;
        Post_Graduction = post_Graduction;
        Degree_Diploma = degree_Diploma;
        Additional_certificate = additional_certificate;
        Employee = employee;
    }
}

