package com.dataversity.ventureagro.pojo;

import com.google.gson.annotations.SerializedName;

public class PersonalInfoResponsePojo {
    @SerializedName("status")
    private String status;

    public PersonalInfoResponsePojo(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

