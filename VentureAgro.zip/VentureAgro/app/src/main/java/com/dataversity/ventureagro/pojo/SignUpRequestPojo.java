package com.dataversity.ventureagro.pojo;

import com.google.gson.annotations.SerializedName;

public class SignUpRequestPojo {
    @SerializedName("username")
    private String username;

    @SerializedName("Email")
    private String Email;

    @SerializedName("password")
    private String password;

    @SerializedName("countryCode")
    private String countryCode;

    @SerializedName("Phone_No")
    private String Phone_No;

    public SignUpRequestPojo(String username, String email, String password, String countryCode, String phone_No) {
        this.username = username;
        Email = email;
        this.password = password;
        this.countryCode = countryCode;
        Phone_No = phone_No;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhone_No() {
        return Phone_No;
    }

    public void setPhone_No(String phone_No) {
        Phone_No = phone_No;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
}

