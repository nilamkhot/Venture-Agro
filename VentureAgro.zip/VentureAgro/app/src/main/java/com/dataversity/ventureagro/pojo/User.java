package com.dataversity.ventureagro.pojo;

import com.google.gson.annotations.SerializedName;

public class User {

    @SerializedName("verified")
    private boolean verified;

    @SerializedName("role")
    private String role;

    @SerializedName("_id")
    private String _id;

    @SerializedName("username")
    private String username;

    @SerializedName("Email")
    private String Email;

    @SerializedName("Phone_No")
    private String Phone_No;

    @SerializedName("countryCode")
    private String countryCode;

    @SerializedName("salt")
    private String salt;

    public User(String role, String _id, String username, String email, String phone_No, String countryCode) {
        this.role = role;
        this._id = _id;
        this.username = username;
        Email = email;
        Phone_No = phone_No;
        this.countryCode = countryCode;
    }

    public User(String _id, String username, String email) {
        this._id = _id;
        this.username = username;
        Email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhone_No() {
        return Phone_No;
    }

    public void setPhone_No(String phone_No) {
        Phone_No = phone_No;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public boolean isVerified() {
        return verified;
    }

    public void setVerified(boolean verified) {
        this.verified = verified;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
}
