package com.dataversity.ventureagro.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.dataversity.ventureagro.ApplyForLeave;
import com.dataversity.ventureagro.KYCRegistrationActivity;
import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.UploadPhotoActivity;
import com.dataversity.ventureagro.adapter.AttendanceListAdapter;
import com.dataversity.ventureagro.model.AttendencePojo;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class AttendanceFragment extends Fragment {
    Button apply_for_leave,start_day;
    RecyclerView attendance_recyclerview;
    LinearLayoutManager category_layoutManager;
    AttendanceListAdapter attendanceListAdapter;
    AttendencePojo attendencePojo;
    private ArrayList<AttendencePojo> attendencePojoArrayList= new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_attendance, container, false);

        apply_for_leave = root.findViewById(R.id.apply_for_leave);
        start_day = root.findViewById(R.id.start_day);

        ShowAttendanceList(root);

        apply_for_leave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), ApplyForLeave.class);
                startActivity(intent);
            }
        });

        start_day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), UploadPhotoActivity.class);
                startActivity(intent);
            }
        });

        return root;
    }

    private void ShowAttendanceList(View root) {

        attendance_recyclerview = root.findViewById(R.id.attendance_recyclerview);

        category_layoutManager = new GridLayoutManager(getContext(), 1);
        attendanceListAdapter = new AttendanceListAdapter();
        // Set the layout manager
        // and adapter for items
        // of the parent recyclerview

        attendanceListAdapter.setListContent(attendencePojoArrayList);
        attendance_recyclerview.setAdapter(attendanceListAdapter);
        attendance_recyclerview.setLayoutManager(category_layoutManager);

    }
}