package com.dataversity.ventureagro.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.dataversity.ventureagro.ApplyForLeave;
import com.dataversity.ventureagro.CollectionMasterActivity;
import com.dataversity.ventureagro.R;
import com.dataversity.ventureagro.UploadPhotoActivity;
import com.dataversity.ventureagro.adapter.AttendanceListAdapter;
import com.dataversity.ventureagro.model.AttendencePojo;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class CollectionFragment extends Fragment {


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_notifications, container, false);

        Intent intent = new Intent(getContext(), CollectionMasterActivity.class);
        getContext().startActivity(intent);

        return root;
    }


}