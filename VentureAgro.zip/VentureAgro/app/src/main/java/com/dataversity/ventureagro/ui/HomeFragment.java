package com.dataversity.ventureagro.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.dataversity.ventureagro.CollectionMasterActivity;
import com.dataversity.ventureagro.KYCRegistrationActivity;
import com.dataversity.ventureagro.OrderHistoryActivity;
import com.dataversity.ventureagro.R;

public class HomeFragment extends Fragment {
    Button update;
    LinearLayout order, collection;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        update = root.findViewById(R.id.update);
        order = root.findViewById(R.id.order);
        collection = root.findViewById(R.id.collection);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), KYCRegistrationActivity.class);
                startActivity(intent);
            }
        });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), OrderHistoryActivity.class);
                startActivity(intent);
            }
        });

        collection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), CollectionMasterActivity.class);
                startActivity(intent);
            }
        });

        return root;
    }
}