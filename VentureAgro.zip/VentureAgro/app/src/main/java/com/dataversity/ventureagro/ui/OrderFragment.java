package com.dataversity.ventureagro.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dataversity.ventureagro.CollectionMasterActivity;
import com.dataversity.ventureagro.OrderHistoryActivity;
import com.dataversity.ventureagro.R;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class OrderFragment extends Fragment {


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_notifications, container, false);

        Intent intent = new Intent(getContext(), OrderHistoryActivity.class);
        getContext().startActivity(intent);

        return root;
    }


}