package com.dataversity.ventureagro.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.dataversity.ventureagro.CheckOutActivity;
import com.dataversity.ventureagro.CollectionDetailsActivity;
import com.dataversity.ventureagro.Dashboard;
import com.dataversity.ventureagro.KycDetailsActivity;
import com.dataversity.ventureagro.OrderHistoryActivity;
import com.dataversity.ventureagro.OrderSummaryActivity;
import com.dataversity.ventureagro.PersonalDetailsActivity;
import com.dataversity.ventureagro.R;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {
    ImageButton personal_detail,order_summery,collection_details,kyc_details;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_profile, container, false);

        personal_detail = root.findViewById(R.id.personal_detail);
        order_summery = root.findViewById(R.id.order_summery);
        collection_details = root.findViewById(R.id.collection_details);
        kyc_details = root.findViewById(R.id.kyc_details);

        personal_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), PersonalDetailsActivity.class);
                startActivity(intent);
            }
        });

        order_summery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), OrderSummaryActivity.class);
                startActivity(intent);
            }
        });

        collection_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), CollectionDetailsActivity.class);
                startActivity(intent);
            }
        });

        kyc_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), KycDetailsActivity.class);
                startActivity(intent);
            }
        });

        return root;
    }


}