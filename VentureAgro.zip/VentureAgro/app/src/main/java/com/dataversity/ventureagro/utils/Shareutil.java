package com.dataversity.ventureagro.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.dataversity.ventureagro.pojo.EducationalDetailstPojo;
import com.dataversity.ventureagro.pojo.EmployeePojo;
import com.dataversity.ventureagro.pojo.PersonalInfoRequestPojo;
import com.dataversity.ventureagro.pojo.User;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class Shareutil {
    public static final String MY_PREFS_NAME = "MyPrefsFile";
    public static final String MY_PREFS_NAME1 = "MyPrefsFile1";

    public static void saveId(Context context, String loginID){
            SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
            editor.putString("_id", loginID);
            editor.apply();
    }

    public static String getID(Context context){
            SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
            String loginId = prefs.getString("_id", "");//"No name defined" is the default value.

            return loginId;
    }

    public static void saveSinUpResponse(Context context, User user){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
        editor.putString("userId", user.get_id());
        editor.putString("role", user.getUsername());
        editor.putString("username", user.getUsername());
        editor.putString("Email", user.getEmail());
        editor.putString("Phone_No", user.getPhone_No());
        editor.putString("countryCode", user.getCountryCode());
        editor.putString("salt", user.getSalt());

        editor.apply();
    }

    public static User getSignUpResponse(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        String userId = prefs.getString("userId", "");//"No name defined" is the default value.
        String role = prefs.getString("role", "");
        String username = prefs.getString("username", "");
        String Email = prefs.getString("Email", "");
        String Phone_No = prefs.getString("Phone_No", "");
        String countryCode = prefs.getString("countryCode", "");
        User user = new User(role,userId,username,Email,Phone_No,countryCode);

        return user;
    }

    public static void savePersonalInfo(Context context, PersonalInfoRequestPojo personalInfoRequestPojo){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
        editor.putString("userId", personalInfoRequestPojo.getUserId());
        editor.putString("Name", personalInfoRequestPojo.getUsername());
        editor.putString("Email", personalInfoRequestPojo.getEmail());
        editor.putString("Phone", personalInfoRequestPojo.getPhone_No());
        editor.putString("date", personalInfoRequestPojo.getDate());
        editor.putString("city", personalInfoRequestPojo.getCity());
        editor.putString("address", personalInfoRequestPojo.getAddress());
        editor.putString("Gender", personalInfoRequestPojo.getGender());

        editor.apply();
    }

    public static PersonalInfoRequestPojo getPersonalInfo(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        String userId = prefs.getString("userId", "");//"No name defined" is the default value.
        String Name = prefs.getString("Name", "");
        String Email = prefs.getString("Email", "");
        String phone = prefs.getString("Phone", "");
        String date = prefs.getString("date", "");
        String city = prefs.getString("city", "");
        String address = prefs.getString("address", "");
        String Gender = prefs.getString("Gender", "");
        PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(userId,Name,Email,phone,date,city,address,Gender);

        return personalInfoRequestPojo;
    }

    public static void saveAdharCardInfo(Context context, PersonalInfoRequestPojo personalInfoRequestPojo){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("adhar_name", personalInfoRequestPojo.getAadhar_card_name());
        editor.putString("adhar_number", personalInfoRequestPojo.getDigit_number());
        editor.putString("adhar_front", personalInfoRequestPojo.getFront_side_photo());
        editor.putString("adhar_back", personalInfoRequestPojo.getBack_side_photo());

        editor.apply();
    }

    public static PersonalInfoRequestPojo getAdharInfo(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String adhar_name = prefs.getString("adhar_name", "");//"No name defined" is the default value.
        String adhar_number = prefs.getString("adhar_number", "");
        String adhar_front = prefs.getString("adhar_front", "");
        String adhar_back = prefs.getString("adhar_back", "");
        PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(adhar_name,adhar_number,adhar_front,adhar_back);

        return personalInfoRequestPojo;
    }

    public static void savePanCardInfo(Context context, PersonalInfoRequestPojo personalInfoRequestPojo){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("userId", personalInfoRequestPojo.getUserId());
        editor.putString("pan_name", personalInfoRequestPojo.getPAN_card_name());
        editor.putString("pan_number", personalInfoRequestPojo.getPAN_number());
        editor.putString("pan_front", personalInfoRequestPojo.getPan_cardphoto_selfi());
        editor.putString("pan_back", personalInfoRequestPojo.getPAN_card_photo());

        editor.apply();
    }

    public static PersonalInfoRequestPojo getPanInfo(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String userId = prefs.getString("userId", "");
        String pan_name = prefs.getString("pan_name", "");//"No name defined" is the default value.
        String pan_number = prefs.getString("pan_number", "");
        String pan_front = prefs.getString("pan_front", "");
        String pan_back = prefs.getString("pan_back", "");
        PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(userId,pan_name,pan_number,pan_front,pan_back);

        return personalInfoRequestPojo;
    }

    //vehicle info
    public static void saveVehicledInfo(Context context, PersonalInfoRequestPojo personalInfoRequestPojo){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("vehicle_model", personalInfoRequestPojo.getVechile_model());
        editor.putString("vehicle_number", personalInfoRequestPojo.getVechile_number());
        editor.putString("licence_number", personalInfoRequestPojo.getDriving_license());
        editor.putString("licence_photo", personalInfoRequestPojo.getDriving_license_photo());

        editor.apply();
    }

    public static PersonalInfoRequestPojo getVehicleInfo(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String vehicle_model = prefs.getString("vehicle_model", "");
        String vehicle_number = prefs.getString("vehicle_number", "");//"No name defined" is the default value.
        String licence_number = prefs.getString("licence_number", "");
        String licence_photo = prefs.getString("licence_photo", "");
        PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(0,vehicle_model,vehicle_number,licence_number,licence_photo);

        return personalInfoRequestPojo;
    }

    //vehicle info
    public static void saveContactInfo(Context context, PersonalInfoRequestPojo personalInfoRequestPojo){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("contact_name", personalInfoRequestPojo.getEmergency_contactname());
        editor.putString("contact_number", personalInfoRequestPojo.getEmergency_contactnumber());
        editor.putString("relation", personalInfoRequestPojo.getRelation());

        editor.apply();
    }

    public static PersonalInfoRequestPojo getContactInfo(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String contact_name = prefs.getString("contact_name", "");
        String contact_number = prefs.getString("contact_number", "");//"No name defined" is the default value.
        String relation = prefs.getString("relation", "");

        PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(contact_name,contact_number,relation);

        return personalInfoRequestPojo;
    }

    //bank info
    public static void saveBankInfo(Context context, PersonalInfoRequestPojo personalInfoRequestPojo){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("account_number", personalInfoRequestPojo.getAccount_number());
        editor.putString("re_enter_account", personalInfoRequestPojo.getReenter_accountnumber());
        editor.putString("ifsc", personalInfoRequestPojo.getIFSC_code());
        editor.putString("branch", personalInfoRequestPojo.getBranch());
        editor.putString("cancel_cheque", personalInfoRequestPojo.getCancel_chequephoto());
        editor.putString("statement", personalInfoRequestPojo.getBank_statement_last3month());

        editor.apply();
    }

    public static PersonalInfoRequestPojo getBankInfo(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String account_number = prefs.getString("account_number", "");
        String re_enter_account = prefs.getString("re_enter_account", "");//"No name defined" is the default value.
        String ifsc = prefs.getString("ifsc", "");
        String branch = prefs.getString("branch", "");
        String cancel_cheque = prefs.getString("cancel_cheque", "");
        String statement = prefs.getString("statement", "");

        PersonalInfoRequestPojo personalInfoRequestPojo = new PersonalInfoRequestPojo(account_number,re_enter_account,ifsc,branch,statement,cancel_cheque);

        return personalInfoRequestPojo;
    }


    //save school
    public static void saveschool(Context context, List<EducationalDetailstPojo> educationalDetailstPojos){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("name", educationalDetailstPojos.get(0).getName());
        editor.putString("year", educationalDetailstPojos.get(0).getYear());
        editor.putString("state", educationalDetailstPojos.get(0).getState());
        editor.putString("board", educationalDetailstPojos.get(0).getBoard());

        editor.apply();
    }

    public static List<EducationalDetailstPojo> getschool(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String name = prefs.getString("name", "");
        String year = prefs.getString("year", "");//"No name defined" is the default value.
        String state = prefs.getString("state", "");
        String board = prefs.getString("board", "");

        List<EducationalDetailstPojo> educationalDetailstPojoList = new ArrayList<>();
        educationalDetailstPojoList.add(new EducationalDetailstPojo(name,year,state,board));

        return educationalDetailstPojoList;
    }

    //save school
    public static void savecollege(Context context, List<EducationalDetailstPojo> educationalDetailstPojos){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("name", educationalDetailstPojos.get(0).getName());
        editor.putString("year", educationalDetailstPojos.get(0).getYear());
        editor.putString("state", educationalDetailstPojos.get(0).getState());
        editor.putString("board", educationalDetailstPojos.get(0).getBoard());

        editor.apply();
    }

    public static List<EducationalDetailstPojo> getcollege(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String name = prefs.getString("name", "");
        String year = prefs.getString("year", "");//"No name defined" is the default value.
        String state = prefs.getString("state", "");
        String board = prefs.getString("board", "");

        List<EducationalDetailstPojo> educationalDetailstPojoList = new ArrayList<>();
        educationalDetailstPojoList.add(new EducationalDetailstPojo(name,year,state,board));

        return educationalDetailstPojoList;
    }

    //save school
    public static void savegraducation(Context context, List<EducationalDetailstPojo> educationalDetailstPojos){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("name", educationalDetailstPojos.get(0).getName());
        editor.putString("year", educationalDetailstPojos.get(0).getYear());
        editor.putString("state", educationalDetailstPojos.get(0).getState());
        editor.putString("board", educationalDetailstPojos.get(0).getBoard());

        editor.apply();
    }

    public static List<EducationalDetailstPojo> getgraducation(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String name = prefs.getString("name", "");
        String year = prefs.getString("year", "");//"No name defined" is the default value.
        String state = prefs.getString("state", "");
        String board = prefs.getString("board", "");

        List<EducationalDetailstPojo> educationalDetailstPojoList = new ArrayList<>();
        educationalDetailstPojoList.add(new EducationalDetailstPojo(name,year,state,board));

        return educationalDetailstPojoList;
    }


    //save school
    public static void savepostgraducation(Context context, List<EducationalDetailstPojo> educationalDetailstPojos){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("name", educationalDetailstPojos.get(0).getName());
        editor.putString("year", educationalDetailstPojos.get(0).getYear());
        editor.putString("state", educationalDetailstPojos.get(0).getState());
        editor.putString("board", educationalDetailstPojos.get(0).getBoard());

        editor.apply();
    }

    public static List<EducationalDetailstPojo> getpostgraducation(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String name = prefs.getString("name", "");
        String year = prefs.getString("year", "");//"No name defined" is the default value.
        String state = prefs.getString("state", "");
        String board = prefs.getString("board", "");

        List<EducationalDetailstPojo> educationalDetailstPojoList = new ArrayList<>();
        educationalDetailstPojoList.add(new EducationalDetailstPojo(name,year,state,board));

        return educationalDetailstPojoList;
    }


    //save school
    public static void savedegree(Context context, List<EducationalDetailstPojo> educationalDetailstPojos){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("name", educationalDetailstPojos.get(0).getName());
        editor.putString("year", educationalDetailstPojos.get(0).getYear());
        editor.putString("state", educationalDetailstPojos.get(0).getState());
        editor.putString("board", educationalDetailstPojos.get(0).getBoard());

        editor.apply();
    }

    public static List<EducationalDetailstPojo> getdegree(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String name = prefs.getString("name", "");
        String year = prefs.getString("year", "");//"No name defined" is the default value.
        String state = prefs.getString("state", "");
        String board = prefs.getString("board", "");

        List<EducationalDetailstPojo> educationalDetailstPojoList = new ArrayList<>();
        educationalDetailstPojoList.add(new EducationalDetailstPojo(name,year,state,board));

        return educationalDetailstPojoList;
    }

    public static void saveAdditional(Context context, String addtional){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
        editor.putString("addtional", addtional);
        editor.apply();
    }

    public static String getAdditional(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        String addtional = prefs.getString("addtional", "");//"No name defined" is the default value.

        return addtional;
    }

    //save company first
    public static void saveCompanyFirst(Context context, EmployeePojo employeePojo){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("CompanyName", employeePojo.getCompanyName());
        editor.putString("start_date", employeePojo.getStart_date());
        editor.putString("end_date", employeePojo.getEnd_date());
        editor.putString("Designation", employeePojo.getDesignation());
        editor.putString("Job_Description", employeePojo.getJob_Description());
        editor.putString("Achivement", employeePojo.getAchivement());
        editor.putString("Skills", employeePojo.getSkills());

        editor.apply();
    }

    public static EmployeePojo getCompanyFirst(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String CompanyName = prefs.getString("CompanyName", "");
        String start_date = prefs.getString("start_date", "");//"No name defined" is the default value.
        String end_date = prefs.getString("end_date", "");
        String Designation = prefs.getString("Designation", "");
        String Job_Description = prefs.getString("Job_Description", "");
        String Achivement = prefs.getString("Achivement", "");
        String Skills = prefs.getString("Skills", "");

        EmployeePojo employeePojo = new EmployeePojo(CompanyName,start_date,end_date,Designation,Job_Description,Achivement,Skills);
        return employeePojo;
    }


    //save company second
    public static void saveCompanySecond(Context context, EmployeePojo employeePojo){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("CompanyName", employeePojo.getCompanyName());
        editor.putString("start_date", employeePojo.getStart_date());
        editor.putString("end_date", employeePojo.getEnd_date());
        editor.putString("Designation", employeePojo.getDesignation());
        editor.putString("Job_Description", employeePojo.getJob_Description());
        editor.putString("Achivement", employeePojo.getAchivement());
        editor.putString("Skills", employeePojo.getSkills());

        editor.apply();
    }

    public static EmployeePojo getCompanySecond(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String CompanyName = prefs.getString("CompanyName", "");
        String start_date = prefs.getString("start_date", "");//"No name defined" is the default value.
        String end_date = prefs.getString("end_date", "");
        String Designation = prefs.getString("Designation", "");
        String Job_Description = prefs.getString("Job_Description", "");
        String Achivement = prefs.getString("Achivement", "");
        String Skills = prefs.getString("Skills", "");

        EmployeePojo employeePojo = new EmployeePojo(CompanyName,start_date,end_date,Designation,Job_Description,Achivement,Skills);
        return employeePojo;
    }

    //save company third
    public static void saveCompanyThird(Context context, EmployeePojo employeePojo){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE).edit();
        editor.putString("CompanyName", employeePojo.getCompanyName());
        editor.putString("start_date", employeePojo.getStart_date());
        editor.putString("end_date", employeePojo.getEnd_date());
        editor.putString("Designation", employeePojo.getDesignation());
        editor.putString("Job_Description", employeePojo.getJob_Description());
        editor.putString("Achivement", employeePojo.getAchivement());
        editor.putString("Skills", employeePojo.getSkills());

        editor.apply();
    }

    public static EmployeePojo getCompanyThird(Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME1, MODE_PRIVATE);
        String CompanyName = prefs.getString("CompanyName", "");
        String start_date = prefs.getString("start_date", "");//"No name defined" is the default value.
        String end_date = prefs.getString("end_date", "");
        String Designation = prefs.getString("Designation", "");
        String Job_Description = prefs.getString("Job_Description", "");
        String Achivement = prefs.getString("Achivement", "");
        String Skills = prefs.getString("Skills", "");

        EmployeePojo employeePojo = new EmployeePojo(CompanyName,start_date,end_date,Designation,Job_Description,Achivement,Skills);
        return employeePojo;
    }

}
