package com.dataversity.ventureagro.utils;

import android.app.ProgressDialog;
import android.content.Context;

public class StaticDialog {
    public static ProgressDialog progress;

    public static ProgressDialog setDialog(Context context) {
        progress = ProgressDialog.show(context,"Please wait...", "", true);
        /*progress.setMessage("Wait...");
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.setCancelable(false);
        progress.setIndeterminate(true);*/

        return progress;
    }

}
